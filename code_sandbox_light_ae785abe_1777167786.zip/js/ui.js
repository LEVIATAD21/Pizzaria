/* ============================================================
 * ui.js — Helpers de UI compartilhados
 * ============================================================ */
(function (global) {
  'use strict';

  function toast(msg, type) {
    type = type || 'info';
    const colors = {
      info: '#1f2937', success: '#059669', error: '#dc2626', warn: '#d97706'
    };
    let host = document.getElementById('mdp-toast-host');
    if (!host) {
      host = document.createElement('div');
      host.id = 'mdp-toast-host';
      host.style.cssText = 'position:fixed;top:16px;left:50%;transform:translateX(-50%);z-index:99999;display:flex;flex-direction:column;gap:8px;pointer-events:none';
      document.body.appendChild(host);
    }
    const t = document.createElement('div');
    t.style.cssText =
      'background:' + (colors[type] || colors.info) +
      ';color:#fff;padding:12px 18px;border-radius:10px;font:500 14px system-ui;' +
      'box-shadow:0 8px 24px rgba(0,0,0,.25);max-width:90vw;animation:mdpToastIn .25s ease';
    t.textContent = msg;
    host.appendChild(t);
    setTimeout(function () { t.style.opacity = '0'; t.style.transition = 'opacity .3s'; }, 2700);
    setTimeout(function () { try { host.removeChild(t); } catch (_) {} }, 3100);
  }

  function confirmDialog(message) {
    return new Promise(function (resolve) {
      const ok = window.confirm(message);
      resolve(ok);
    });
  }

  function promptDialog(message, defaultValue) {
    return new Promise(function (resolve) {
      const v = window.prompt(message, defaultValue || '');
      resolve(v);
    });
  }

  function backButton(targetHref, label) {
    label = label || 'Voltar';
    const html = '<button onclick="MDPUI.handleBack(\'' + (targetHref || '') + '\')" ' +
      'class="mdp-back-btn" aria-label="' + label + '" type="button">' +
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M19 12H5M12 19l-7-7 7-7"/></svg><span>' + label + '</span></button>';
    return html;
  }

  function handleBack(targetHref) {
    if (history.length > 1 && document.referrer && document.referrer !== location.href) {
      history.back();
    } else if (targetHref) {
      location.href = targetHref;
    } else {
      location.href = 'index.html';
    }
  }

  function formatBRL(v) {
    return 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',');
  }

  function formatTimeAgo(ms) {
    const diff = Date.now() - ms;
    if (diff < 60000) return 'agora';
    if (diff < 3600000) return Math.floor(diff / 60000) + ' min';
    if (diff < 86400000) return Math.floor(diff / 3600000) + 'h';
    return Math.floor(diff / 86400000) + 'd';
  }

  global.MDPUI = {
    toast, confirmDialog, promptDialog,
    backButton, handleBack,
    formatBRL, formatTimeAgo
  };
})(window);

// CSS injetado para botões de voltar e toast
(function () {
  const style = document.createElement('style');
  style.textContent =
    '.mdp-back-btn{display:inline-flex;align-items:center;gap:6px;background:transparent;border:none;color:inherit;font:600 15px system-ui;cursor:pointer;padding:8px 12px;border-radius:8px;transition:background .15s}' +
    '.mdp-back-btn:hover{background:rgba(0,0,0,.06)}' +
    '@keyframes mdpToastIn{from{opacity:0;transform:translate(-50%,-10px)}to{opacity:1;transform:translate(-50%,0)}}';
  document.head.appendChild(style);
})();
