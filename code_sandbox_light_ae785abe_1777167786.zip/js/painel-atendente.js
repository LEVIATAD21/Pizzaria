/* ============================================================
 * painel-atendente.js — Atendente / Logística
 * Funcionalidades:
 * - Pré-aprovar motoboys (PENDENTE → PRÉ_APROVADO)
 * - Reprovar com motivo
 * - Registrar pedidos do balcão (presencial / telefone)
 * - Ver seus próprios pedidos registrados
 * ============================================================ */
(function () {
  'use strict';

  let session = null;
  let pendentes = [];
  let produtos = [];
  let meusPedidos = [];
  let cartBalcao = []; // {id,nome,preco,qty}

  const ESC = MDPSecurity.escapeHtml;
  const BRL = MDPUI.formatBRL;

  document.getElementById('back-slot').innerHTML = MDPUI.backButton('login.html?staff=1');
  init();

  async function init() {
    session = await MDPSecurity.requireAuth(['atendente'], 'login.html?staff=1');
    document.getElementById('user-chip').textContent = '👤 ' + (session.nome || '').split(' ')[0];
    document.getElementById('user-chip').addEventListener('click', logout);

    document.querySelectorAll('.tab').forEach(t => {
      t.addEventListener('click', () => switchTab(t.dataset.tab));
    });

    await refresh();
    setInterval(refresh, 15000);
  }

  async function refresh() {
    await Promise.all([loadPendentes(), loadProdutos(), loadMeusPedidos()]);
    renderPendentes();
    renderBalcao();
    renderMeusPedidos();
  }

  function switchTab(name) {
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    document.getElementById('panel-motoboys').style.display = name === 'motoboys' ? 'block' : 'none';
    document.getElementById('panel-balcao').style.display = name === 'balcao' ? 'block' : 'none';
    document.getElementById('panel-meus-pedidos').style.display = name === 'meus-pedidos' ? 'block' : 'none';
  }

  // ===== Motoboys pendentes =====
  async function loadPendentes() {
    const users = await MDPApi.list('users', { limit: 500 });
    pendentes = users.filter(u => u.role === 'motoboy' && u.status === 'pendente' && !u.deleted);
    document.getElementById('badge-pend').textContent = pendentes.length;
  }

  async function renderPendentes() {
    const host = document.getElementById('panel-motoboys');
    host.innerHTML = '<h2 style="margin-bottom:12px">Motoboys aguardando pré-aprovação</h2>';
    if (!pendentes.length) {
      host.innerHTML += '<div class="mdp-empty"><div class="icon">✅</div>Nenhum cadastro pendente.</div>';
      return;
    }
    const dados = await MDPApi.list('motoboys_dados', { limit: 500 });
    pendentes.forEach(u => {
      const d = dados.find(x => x.user_id === u.id) || {};
      const card = document.createElement('div');
      card.className = 'motoboy-card';
      card.innerHTML = `
        <img src="${ESC(d.foto_3x4_data || '')}" alt="" onerror="this.style.opacity=.3">
        <div class="info">
          <b>${ESC(u.nome)}</b>
          <small>📞 ${ESC(MDPValidators.maskTelefone(u.telefone||''))} · ✉ ${ESC(u.email)}</small>
          <small>🪪 CPF ${ESC(MDPValidators.maskCPFHidden(d.cpf||''))} · CNH ${ESC(d.cnh||'-')} (${ESC(d.cnh_categoria||'')})</small>
          <small>🛵 ${ESC(d.moto_modelo||'')} ${ESC(d.moto_cor||'')} · Placa <b>${ESC(MDPValidators.maskPlaca(d.placa||''))}</b></small>
        </div>
        <div style="display:flex;flex-direction:column;gap:6px">
          <button class="mdp-btn secondary" onclick='verDocumentos(${JSON.stringify(d.foto_cnh_data||"")})'>👁 Ver CNH</button>
          <button class="mdp-btn success" onclick="preAprovar('${ESC(u.id)}')">✓ Pré-aprovar</button>
          <button class="mdp-btn danger" onclick="reprovarMotoboy('${ESC(u.id)}')">✗ Reprovar</button>
        </div>
      `;
      host.appendChild(card);
    });
  }

  window.verDocumentos = function (data) {
    if (!data) return MDPUI.toast('Foto não disponível', 'warn');
    const w = window.open('', '_blank');
    w.document.write('<html><body style="margin:0;background:#000;display:flex;align-items:center;justify-content:center;min-height:100vh"><img src="'+data+'" style="max-width:100%;max-height:100vh"></body></html>');
  };

  window.preAprovar = async function (userId) {
    const ok = await MDPUI.confirmDialog('Pré-aprovar este motoboy? O gerente fará a aprovação final.');
    if (!ok) return;
    try {
      await MDPApi.patch('users', userId, {
        status: 'pre_aprovado', pre_aprovado_por: session.uid
      });
      await MDPApi.create('aprovacoes_log', {
        id: 'apr-' + MDPSecurity.randomHex(8),
        motoboy_id: userId, acao: 'pre_aprovacao',
        executado_por: session.uid, executado_por_nome: session.nome,
        executado_por_role: 'atendente', timestamp_ms: Date.now()
      });
      MDPUI.toast('Pré-aprovado! Aguardando gerente.', 'success');
      refresh();
    } catch (e) { console.error(e); MDPUI.toast('Erro ao pré-aprovar', 'error'); }
  };

  window.reprovarMotoboy = async function (userId) {
    const motivo = await MDPUI.promptDialog('Motivo da reprovação:');
    if (!motivo) return;
    try {
      await MDPApi.patch('users', userId, {
        status: 'reprovado', reprovacao_motivo: MDPSecurity.cleanInput(motivo, 200)
      });
      await MDPApi.create('aprovacoes_log', {
        id: 'apr-' + MDPSecurity.randomHex(8),
        motoboy_id: userId, acao: 'reprovacao', motivo: motivo,
        executado_por: session.uid, executado_por_nome: session.nome,
        executado_por_role: 'atendente', timestamp_ms: Date.now()
      });
      MDPUI.toast('Cadastro reprovado.', 'warn');
      refresh();
    } catch (e) { console.error(e); MDPUI.toast('Erro ao reprovar', 'error'); }
  };

  // ===== Pedido de balcão =====
  async function loadProdutos() {
    produtos = (await MDPApi.list('produtos', { limit: 200 })).filter(p => p.ativo !== false && !p.deleted);
  }

  function renderBalcao() {
    const host = document.getElementById('panel-balcao');
    host.innerHTML = `
      <h2 style="margin-bottom:12px">📞 Registrar pedido (balcão / telefone)</h2>
      <div class="mdp-row">
        <div>
          <h3>Produtos</h3>
          <div id="balcao-produtos" style="max-height:380px;overflow-y:auto;border:1px solid var(--border);border-radius:10px;padding:10px"></div>
        </div>
        <div>
          <h3>Pedido em montagem</h3>
          <div id="balcao-cart" style="border:1px solid var(--border);border-radius:10px;padding:10px;min-height:120px"></div>

          <h3 style="margin-top:14px">Cliente</h3>
          <div class="mdp-field">
            <label>Nome *</label>
            <input type="text" id="b-nome" class="mdp-input" maxlength="120">
          </div>
          <div class="mdp-field">
            <label>Telefone *</label>
            <input type="tel" id="b-tel" class="mdp-input" maxlength="16" placeholder="(21) 99999-9999">
          </div>
          <div class="mdp-row">
            <div class="mdp-field">
              <label>CEP</label>
              <input type="text" id="b-cep" class="mdp-input" maxlength="9" placeholder="00000-000">
            </div>
            <div class="mdp-field">
              <label>Número</label>
              <input type="text" id="b-num" class="mdp-input" maxlength="10">
            </div>
          </div>
          <div class="mdp-field">
            <label>Rua</label>
            <input type="text" id="b-rua" class="mdp-input" maxlength="120">
          </div>
          <div class="mdp-row">
            <div class="mdp-field">
              <label>Bairro</label>
              <input type="text" id="b-bairro" class="mdp-input" maxlength="80">
            </div>
            <div class="mdp-field">
              <label>Cidade</label>
              <input type="text" id="b-cidade" class="mdp-input" maxlength="80" value="Queimados">
            </div>
          </div>
          <div class="mdp-field">
            <label>Forma de pagamento</label>
            <select id="b-pgto" class="mdp-select">
              <option value="pix">PIX</option>
              <option value="dinheiro">Dinheiro</option>
              <option value="credito">Crédito</option>
              <option value="debito">Débito</option>
            </select>
          </div>
          <div class="mdp-field">
            <label>Observações</label>
            <textarea id="b-obs" class="mdp-textarea" maxlength="300"></textarea>
          </div>
          <button class="mdp-btn full lg" id="b-confirm">Registrar pedido</button>
        </div>
      </div>
    `;
    renderProdutosBalcao();
    renderCartBalcao();
    document.getElementById('b-tel').addEventListener('input', e => e.target.value = MDPValidators.maskTelefone(e.target.value));
    document.getElementById('b-cep').addEventListener('input', async e => {
      e.target.value = MDPValidators.maskCEP(e.target.value);
      if (e.target.value.replace(/\D/g, '').length === 8) {
        try {
          const d = await MDPValidators.lookupCEP(e.target.value);
          document.getElementById('b-rua').value = d.rua;
          document.getElementById('b-bairro').value = d.bairro;
          document.getElementById('b-cidade').value = d.cidade;
        } catch (_) {}
      }
    });
    document.getElementById('b-confirm').addEventListener('click', confirmarPedidoBalcao);
  }

  function renderProdutosBalcao() {
    const host = document.getElementById('balcao-produtos');
    if (!host) return;
    host.innerHTML = produtos.map(p =>
      `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid #f1f5f9">
        <div>
          <b style="font-size:14px">${ESC(p.nome)}</b><br>
          <small style="color:var(--text-muted)">${BRL(p.preco)}</small>
        </div>
        <button class="mdp-btn" style="padding:6px 12px;font-size:13px" data-id="${ESC(p.id)}">+</button>
      </div>`
    ).join('');
    host.querySelectorAll('button').forEach(b => b.addEventListener('click', () => addCartBalcao(b.dataset.id)));
  }

  function addCartBalcao(id) {
    const p = produtos.find(x => x.id === id);
    if (!p) return;
    const ex = cartBalcao.find(c => c.id === id);
    if (ex) ex.qty++;
    else cartBalcao.push({ id: p.id, nome: p.nome, preco: p.preco, qty: 1 });
    renderCartBalcao();
  }

  function renderCartBalcao() {
    const host = document.getElementById('balcao-cart');
    if (!host) return;
    if (!cartBalcao.length) { host.innerHTML = '<p style="color:var(--text-muted);text-align:center">Adicione itens ao pedido</p>'; return; }
    const total = cartBalcao.reduce((s, i) => s + i.preco * i.qty, 0);
    host.innerHTML = cartBalcao.map((i, idx) =>
      `<div style="display:flex;justify-content:space-between;align-items:center;padding:6px 0">
        <div><b>${i.qty}×</b> ${ESC(i.nome)}</div>
        <div>${BRL(i.preco * i.qty)} <button onclick="removerCartBalcao(${idx})" style="background:none;border:none;color:#dc2626;cursor:pointer;font-size:18px">✕</button></div>
      </div>`
    ).join('') + `<div style="border-top:2px solid var(--border);margin-top:6px;padding-top:6px;display:flex;justify-content:space-between"><b>Total</b><b style="color:var(--primary-dark)">${BRL(total + 6)}</b></div>`;
  }

  window.removerCartBalcao = function (idx) {
    cartBalcao.splice(idx, 1);
    renderCartBalcao();
  };

  async function confirmarPedidoBalcao() {
    if (!cartBalcao.length) return MDPUI.toast('Adicione itens', 'error');
    const nome = document.getElementById('b-nome').value.trim();
    const tel = document.getElementById('b-tel').value;
    if (!nome) return MDPUI.toast('Nome do cliente obrigatório', 'error');
    if (!MDPValidators.isValidTelefone(tel)) return MDPUI.toast('Telefone inválido', 'error');

    const subtotal = cartBalcao.reduce((s, i) => s + i.preco * i.qty, 0);
    const itens = cartBalcao.map(i => ({ id: i.id, nome: i.nome, qty: i.qty, preco: i.preco, subtotal: i.qty * i.preco }));
    const addr = {
      cep: document.getElementById('b-cep').value.replace(/\D/g, ''),
      rua: document.getElementById('b-rua').value.trim(),
      numero: document.getElementById('b-num').value.trim(),
      bairro: document.getElementById('b-bairro').value.trim(),
      cidade: document.getElementById('b-cidade').value.trim(),
      estado: 'RJ'
    };

    try {
      await MDPApi.create('pedidos', {
        id: 'ped-' + MDPSecurity.randomHex(8),
        numero: '#' + Math.floor(1000 + Math.random() * 9000),
        cliente_id: '', cliente_nome: nome,
        cliente_telefone: tel.replace(/\D/g, ''),
        endereco_json: JSON.stringify(addr),
        itens_json: JSON.stringify(itens),
        subtotal: subtotal, taxa_entrega: 6,
        total: subtotal + 6,
        forma_pagamento: document.getElementById('b-pgto').value,
        observacoes: MDPSecurity.cleanInput(document.getElementById('b-obs').value, 300),
        status: 'pendente',
        motoboy_id: '',
        origem: 'balcao',
        criado_por: session.uid,
        created_at_ms: Date.now()
      });
      cartBalcao = [];
      MDPUI.toast('Pedido registrado!', 'success');
      renderBalcao();
      refresh();
    } catch (e) { console.error(e); MDPUI.toast('Erro ao registrar', 'error'); }
  }

  // ===== Meus Pedidos =====
  async function loadMeusPedidos() {
    const all = await MDPApi.list('pedidos', { limit: 200, sort: 'created_at_ms' });
    meusPedidos = all.filter(p => p.criado_por === session.uid && !p.deleted)
      .sort((a, b) => (b.created_at_ms || 0) - (a.created_at_ms || 0)).slice(0, 50);
  }

  function renderMeusPedidos() {
    const host = document.getElementById('panel-meus-pedidos');
    host.innerHTML = '<h2 style="margin-bottom:12px">Pedidos que registrei</h2>';
    if (!meusPedidos.length) {
      host.innerHTML += '<div class="mdp-empty"><div class="icon">📋</div>Nenhum pedido registrado ainda.</div>';
      return;
    }
    const labels = { pendente: 'Pendente', preparando: 'Preparando', pronto: 'Pronto', saiu_entrega: 'Saiu p/ Entrega', entregue: 'Entregue', cancelado: 'Cancelado' };
    host.innerHTML += meusPedidos.map(p => {
      const addr = JSON.parse(p.endereco_json || '{}');
      return `<div class="mdp-card" style="margin-bottom:8px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
          <b>${ESC(p.numero)} · ${ESC(p.cliente_nome)}</b>
          <span class="badge ${ESC(p.status === 'saiu_entrega' ? 'saiu' : p.status)}">${ESC(labels[p.status] || p.status)}</span>
        </div>
        <small style="color:var(--text-muted)">${ESC(addr.rua||'')}, ${ESC(addr.numero||'')} · ${BRL(p.total)} · ${MDPUI.formatTimeAgo(p.created_at_ms)}</small>
      </div>`;
    }).join('');
  }

  function logout() {
    if (confirm('Sair?')) {
      MDPSecurity.clearSession();
      location.href = 'index.html';
    }
  }
})();
