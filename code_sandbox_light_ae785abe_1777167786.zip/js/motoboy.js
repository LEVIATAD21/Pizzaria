/* ============================================================
 * motoboy.js — App do Entregador
 * - Scanner QR funcional (jsQR + getUserMedia)
 * - GPS watchPosition + Wake Lock
 * - Bloqueio de logout em turno
 * ============================================================ */
(function () {
  'use strict';

  let session = null;
  let dadosMotoboy = null; // motoboys_dados row
  let entregas = [];
  let entregaAtiva = null;
  let watchId = null;
  let wakeLock = null;
  let pingTimer = null;
  let gpsLat = null, gpsLng = null;
  let mapaRota = null, motoMarker = null;
  let pollTimer = null;

  const ESC = MDPSecurity.escapeHtml;
  const BRL = MDPUI.formatBRL;

  document.getElementById('back-slot').innerHTML = MDPUI.backButton('index.html');

  init();

  async function init() {
    session = await MDPSecurity.requireAuth(['motoboy'], 'motoboy-entrada.html');
    await loadDados();
    if (!dadosMotoboy) {
      MDPUI.toast('Dados do motoboy não encontrados', 'error');
      return;
    }
    render();
    startPolling();
    if (dadosMotoboy.online) startGPS();
  }

  async function loadDados() {
    const all = await MDPApi.list('motoboys_dados', { limit: 500 });
    dadosMotoboy = all.find(m => m.user_id === session.uid);
  }

  async function loadEntregas() {
    const all = await MDPApi.list('pedidos', { limit: 200, sort: 'created_at_ms' });
    entregas = all.filter(p =>
      !p.deleted && (
        (p.motoboy_id === session.uid && ['saiu_entrega'].indexOf(p.status) >= 0) ||
        (p.status === 'pronto' && !p.motoboy_id) // disponíveis para pegar
      )
    );
    entregaAtiva = entregas.find(p => p.motoboy_id === session.uid && p.status === 'saiu_entrega') || null;
  }

  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(async function () {
      try {
        await loadDados();
        await loadEntregas();
        render();
      } catch (_) {}
    }, 6000);
  }

  function render() {
    document.getElementById('status-pill').textContent = dadosMotoboy.online ? 'ONLINE' : 'OFFLINE';
    document.getElementById('status-pill').className = 'status-pill ' + (dadosMotoboy.online ? 'online' : 'offline');

    const card = document.getElementById('status-card');
    if (!dadosMotoboy.online) {
      card.innerHTML = `
        <div class="mdp-card" style="text-align:center;padding:30px 20px">
          <div style="font-size:50px">🛵</div>
          <h2 style="color:#fff;margin:8px 0 6px">Olá, ${ESC(session.nome.split(' ')[0])}!</h2>
          <p style="color:#94a3b8;margin-bottom:18px">Para começar a trabalhar, escaneie o QR Code do balcão da loja.</p>
          <button class="big-btn primary" onclick="abrirScanner()">📷 Escanear QR para iniciar turno</button>
          <p style="color:#94a3b8;font-size:12px;margin-top:12px">⚠ Você só consegue ficar online presencialmente na loja.</p>
          <button class="mdp-btn secondary" style="margin-top:18px" onclick="logout()">Sair da conta</button>
        </div>`;
      stopGPS();
      return;
    }
    // Online
    const turnoMin = dadosMotoboy.turno_inicio_ms ? Math.floor((Date.now() - dadosMotoboy.turno_inicio_ms) / 60000) : 0;
    card.innerHTML = `
      <div class="mdp-card" style="text-align:center">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
          <div style="text-align:left">
            <div style="font-size:13px;color:#94a3b8">Em turno há</div>
            <div style="font-size:22px;font-weight:700;color:#10b981">${turnoMin} min</div>
          </div>
          <div style="text-align:right">
            <div style="font-size:13px;color:#94a3b8">Entregas hoje</div>
            <div style="font-size:22px;font-weight:700">${entregas.filter(e=>e.motoboy_id===session.uid).length}</div>
          </div>
        </div>
        ${entregaAtiva ? '' : '<button class="big-btn danger" onclick="abrirScanner(true)">📷 Escanear QR para encerrar turno</button>'}
        ${entregaAtiva ? '<p style="color:#fbbf24;font-size:13px;margin-top:8px">⚠ Você tem entrega ativa. Finalize antes de encerrar o turno.</p>' : ''}
      </div>
    `;

    const host = document.getElementById('entregas-host');
    if (entregaAtiva) {
      const addr = JSON.parse(entregaAtiva.endereco_json || '{}');
      host.innerHTML = `
        <div class="entrega-card ativa">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
            <h3 style="color:#60a5fa">Entrega ATIVA · ${ESC(entregaAtiva.numero)}</h3>
            <span style="font-size:12px;color:#94a3b8">${MDPUI.formatTimeAgo(entregaAtiva.saiu_entrega_ms || entregaAtiva.created_at_ms)}</span>
          </div>
          <div style="margin-bottom:8px">
            <b>${ESC(entregaAtiva.cliente_nome || 'Cliente')}</b><br>
            <small style="color:#94a3b8">${ESC(addr.rua||'')}, ${ESC(addr.numero||'')} ${addr.complemento ? ' — ' + ESC(addr.complemento) : ''}</small><br>
            <small style="color:#94a3b8">${ESC(addr.bairro||'')}</small>
          </div>
          <div style="display:flex;gap:8px;margin-bottom:10px">
            <a href="https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent((addr.rua||'')+', '+(addr.numero||'')+', '+(addr.bairro||'')+', '+(addr.cidade||''))}"
               target="_blank" rel="noopener" class="mdp-btn secondary" style="flex:1;color:#fff">🗺 Rotas no Maps</a>
            <button class="mdp-btn success" style="flex:1" onclick="finalizarEntrega()">✓ Entreguei</button>
          </div>
          <div id="map-rota"></div>
        </div>`;
      initMapaRota();
    } else {
      const disponiveis = entregas.filter(e => e.status === 'pronto' && !e.motoboy_id);
      if (disponiveis.length === 0) {
        host.innerHTML = '<div class="mdp-card" style="text-align:center"><div style="font-size:40px">🍕</div><p style="color:#94a3b8;margin-top:8px">Nenhuma entrega disponível agora.<br>Aguarde novos pedidos!</p></div>';
      } else {
        host.innerHTML = '<h3 style="color:#fff;margin-bottom:10px">Entregas disponíveis</h3>' +
          disponiveis.map(p => {
            const addr = JSON.parse(p.endereco_json || '{}');
            return `<div class="entrega-card">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px">
                <b>${ESC(p.numero)}</b>
                <small style="color:#94a3b8">${MDPUI.formatTimeAgo(p.created_at_ms)}</small>
              </div>
              <div style="font-size:14px;margin-bottom:8px">
                ${ESC(p.cliente_nome||'Cliente')}<br>
                <small style="color:#94a3b8">${ESC(addr.rua||'')}, ${ESC(addr.numero||'')} — ${ESC(addr.bairro||'')}</small>
              </div>
              <button class="big-btn primary" onclick="aceitarEntrega('${ESC(p.id)}')">✋ Aceitar entrega</button>
            </div>`;
          }).join('');
      }
    }
  }

  function initMapaRota() {
    const el = document.getElementById('map-rota');
    if (!el) return;
    if (mapaRota) { mapaRota.remove(); mapaRota = null; }
    const lat = gpsLat || -22.7160, lng = gpsLng || -43.5550;
    mapaRota = L.map(el).setView([lat, lng], 15);
    el.classList.add('map-dark');
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OSM' }).addTo(mapaRota);
    const icon = L.divIcon({ html: '<div style="font-size:30px">🛵</div>', className:'', iconSize:[36,36], iconAnchor:[18,18] });
    motoMarker = L.marker([lat, lng], { icon: icon }).addTo(mapaRota);
  }

  // ===== Scanner QR =====
  let scanStream = null;
  let scanRAF = null;

  window.abrirScanner = async function (isCheckout) {
    if (!MDPSecurity.rateLimit('scan-qr', 10)) { MDPUI.toast('Aguarde antes de escanear novamente', 'warn'); return; }
    document.getElementById('scanner-modal').style.display = 'block';
    const status = document.getElementById('scanner-status');
    status.textContent = 'Solicitando acesso à câmera…';
    try {
      scanStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: 'environment' } }, audio: false
      });
      const video = document.getElementById('scanner-video');
      video.srcObject = scanStream;
      await video.play();
      status.textContent = 'Câmera ativa. Aponte para o QR Code da loja.';
      startScanLoop(isCheckout);
    } catch (e) {
      console.error(e);
      status.textContent = '⚠ Não foi possível acessar a câmera. Verifique a permissão.';
      MDPUI.toast('Permita o acesso à câmera nas configurações', 'error');
    }
  };

  window.closeScanner = function () {
    if (scanRAF) cancelAnimationFrame(scanRAF);
    scanRAF = null;
    if (scanStream) {
      scanStream.getTracks().forEach(t => t.stop());
      scanStream = null;
    }
    document.getElementById('scanner-modal').style.display = 'none';
  };

  function startScanLoop(isCheckout) {
    const video = document.getElementById('scanner-video');
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    let lastDecode = 0;

    function tick() {
      if (!scanStream) return;
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        const now = Date.now();
        if (now - lastDecode > 200) {
          lastDecode = now;
          try {
            const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const code = window.jsQR(img.data, img.width, img.height, { inversionAttempts: 'attemptBoth' });
            if (code && code.data) {
              processQR(code.data, isCheckout);
              return;
            }
          } catch (_) {}
        }
      }
      scanRAF = requestAnimationFrame(tick);
    }
    scanRAF = requestAnimationFrame(tick);
  }

  async function processQR(raw, isCheckout) {
    const token = MDPQR.parseQRPayload(raw);
    const status = document.getElementById('scanner-status');
    if (!token) { status.textContent = '✗ QR Code inválido. Use o QR exibido pelo gerente.'; setTimeout(() => startScanLoop(isCheckout), 1000); return; }
    status.textContent = 'Validando token…';
    try {
      const secret = await MDPApi.getQRSecret();
      if (!secret) { status.textContent = '✗ Sistema indisponível'; return; }
      const valid = await MDPQR.verifyToken(secret, token);
      if (!valid) {
        status.textContent = '✗ Token expirado ou inválido. O QR muda a cada 20s.';
        setTimeout(() => startScanLoop(isCheckout), 1500);
        return;
      }
      status.textContent = '✓ Token válido!';
      closeScanner();
      if (dadosMotoboy.online) {
        await checkOut(token);
      } else {
        await checkIn(token);
      }
    } catch (e) {
      console.error(e); status.textContent = '✗ Erro ao validar';
    }
  }

  async function checkIn(token) {
    await MDPApi.patch('motoboys_dados', dadosMotoboy.id, {
      online: true,
      turno_inicio_ms: Date.now(),
      ultimo_ping_ms: Date.now()
    });
    await MDPApi.create('ponto_log', {
      id: 'pl-' + MDPSecurity.randomHex(8),
      motoboy_id: session.uid,
      motoboy_nome: session.nome,
      acao: 'check_in',
      qr_token: token,
      timestamp_ms: Date.now()
    });
    MDPUI.toast('✓ Turno iniciado! Bom trabalho!', 'success');
    await loadDados(); render(); startGPS();
  }

  async function checkOut(token) {
    if (entregaAtiva) {
      MDPUI.toast('Você tem entrega ativa. Finalize primeiro.', 'error'); return;
    }
    await MDPApi.patch('motoboys_dados', dadosMotoboy.id, {
      online: false,
      turno_inicio_ms: 0
    });
    await MDPApi.create('ponto_log', {
      id: 'pl-' + MDPSecurity.randomHex(8),
      motoboy_id: session.uid,
      motoboy_nome: session.nome,
      acao: 'check_out',
      qr_token: token,
      timestamp_ms: Date.now()
    });
    MDPUI.toast('✓ Turno encerrado. Boa noite!', 'success');
    stopGPS();
    await loadDados(); render();
  }

  // ===== GPS =====
  async function startGPS() {
    if (watchId !== null) return;
    try {
      if ('wakeLock' in navigator) {
        try { wakeLock = await navigator.wakeLock.request('screen'); } catch (_) {}
      }
    } catch (_) {}
    if (!navigator.geolocation) {
      MDPUI.toast('GPS não suportado neste dispositivo', 'warn');
      simulateGPS();
      return;
    }
    watchId = navigator.geolocation.watchPosition(function (pos) {
      gpsLat = pos.coords.latitude; gpsLng = pos.coords.longitude;
      schedulePing();
    }, function (err) {
      console.warn('GPS erro:', err);
      simulateGPS();
    }, { enableHighAccuracy: true, timeout: 15000, maximumAge: 5000 });
  }

  function stopGPS() {
    if (watchId !== null) { navigator.geolocation.clearWatch(watchId); watchId = null; }
    if (pingTimer) { clearInterval(pingTimer); pingTimer = null; }
    if (wakeLock) { try { wakeLock.release(); } catch (_) {} wakeLock = null; }
  }

  function schedulePing() {
    if (pingTimer) return;
    pingTimer = setInterval(sendPing, 8000);
    sendPing();
  }

  async function sendPing() {
    if (!dadosMotoboy.online || gpsLat === null) return;
    try {
      await MDPApi.patch('motoboys_dados', dadosMotoboy.id, {
        ultima_lat: gpsLat, ultima_lng: gpsLng,
        ultimo_ping_ms: Date.now()
      });
      if (motoMarker) motoMarker.setLatLng([gpsLat, gpsLng]);
    } catch (_) {}
  }

  // Simulação se GPS falhar (centro de Queimados)
  function simulateGPS() {
    let lat = -22.7160, lng = -43.5550;
    setInterval(() => {
      lat += (Math.random() - 0.5) * 0.0008;
      lng += (Math.random() - 0.5) * 0.0008;
      gpsLat = lat; gpsLng = lng;
    }, 5000);
    schedulePing();
  }

  // ===== Aceitar / Finalizar entrega =====
  window.aceitarEntrega = async function (pedidoId) {
    if (!dadosMotoboy.online) return MDPUI.toast('Você precisa estar em turno', 'error');
    try {
      await MDPApi.patch('pedidos', pedidoId, {
        motoboy_id: session.uid,
        status: 'saiu_entrega',
        saiu_entrega_ms: Date.now()
      });
      MDPUI.toast('Entrega aceita!', 'success');
      await loadEntregas(); render();
    } catch (e) { console.error(e); MDPUI.toast('Erro ao aceitar', 'error'); }
  };

  window.finalizarEntrega = async function () {
    if (!entregaAtiva) return;
    const ok = await MDPUI.confirmDialog('Confirma a entrega de ' + entregaAtiva.numero + '?');
    if (!ok) return;
    try {
      await MDPApi.patch('pedidos', entregaAtiva.id, {
        status: 'entregue', entregue_ms: Date.now()
      });
      MDPUI.toast('🎉 Entrega concluída!', 'success');
      entregaAtiva = null;
      await loadEntregas(); render();
    } catch (e) { console.error(e); MDPUI.toast('Erro ao finalizar', 'error'); }
  };

  // ===== Logout (bloqueado se em turno) =====
  window.logout = async function () {
    if (dadosMotoboy && dadosMotoboy.online) {
      MDPUI.toast('Você está em turno. Encerre via QR antes de sair.', 'error');
      return;
    }
    MDPSecurity.clearSession();
    location.href = 'index.html';
  };

  // Anti-saída acidental
  window.addEventListener('beforeunload', function (e) {
    if (dadosMotoboy && dadosMotoboy.online) {
      e.preventDefault();
      e.returnValue = 'Você está em turno. Tem certeza?';
    }
  });
})();
