/* ============================================================
 * Mania de Pizza — V3
 * security.js — Núcleo de segurança nível governamental
 * ============================================================
 * - Senhas: SHA-256 + salt 128 bits hex
 * - Sessão: token HMAC + TTL 12h + nonce anti-replay
 * - Comparação timing-safe
 * - Anti-XSS: escape em todas as interpolações DOM
 * - Anti-clickjacking: detecção de iframe
 * - Rate limiting client-side (token bucket)
 * - Validações reais (CPF, CNH, placa Mercosul, CEP, telefone)
 * ============================================================ */
(function (global) {
  'use strict';

  // ===== Anti-prototype-pollution (congelar protótipos) =====
  try {
    Object.freeze(Object.prototype);
    Object.freeze(Array.prototype);
    Object.freeze(Function.prototype);
  } catch (_) {}

  // ===== Anti-clickjacking =====
  try {
    if (window.self !== window.top) {
      // Bloqueia iframe externo
      document.documentElement.innerHTML =
        '<div style="font:bold 18px system-ui;padding:40px;text-align:center;color:#c00">' +
        'Acesso bloqueado: este site não pode ser exibido em frames externos.</div>';
      throw new Error('clickjacking-blocked');
    }
  } catch (e) {
    if (e && e.message === 'clickjacking-blocked') return;
  }

  // ===== Utilidades de cripto (Web Crypto API) =====
  const enc = new TextEncoder();
  const dec = new TextDecoder();

  function bufToHex(buf) {
    const bytes = new Uint8Array(buf);
    let s = '';
    for (let i = 0; i < bytes.length; i++) {
      s += bytes[i].toString(16).padStart(2, '0');
    }
    return s;
  }

  function hexToBuf(hex) {
    const len = hex.length / 2;
    const out = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      out[i] = parseInt(hex.substr(i * 2, 2), 16);
    }
    return out.buffer;
  }

  async function sha256Hex(str) {
    const buf = await crypto.subtle.digest('SHA-256', enc.encode(str));
    return bufToHex(buf);
  }

  async function hmacSha256Hex(key, msg) {
    const k = await crypto.subtle.importKey(
      'raw', enc.encode(key), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']
    );
    const sig = await crypto.subtle.sign('HMAC', k, enc.encode(msg));
    return bufToHex(sig);
  }

  function randomHex(bytes) {
    const a = new Uint8Array(bytes);
    crypto.getRandomValues(a);
    let s = '';
    for (let i = 0; i < a.length; i++) s += a[i].toString(16).padStart(2, '0');
    return s;
  }

  // Timing-safe equal
  function timingSafeEqual(a, b) {
    if (typeof a !== 'string' || typeof b !== 'string') return false;
    if (a.length !== b.length) {
      // ainda faz comparação para não vazar tempo
      let r = 1;
      for (let i = 0; i < Math.max(a.length, b.length); i++) r |= 1;
      return false;
    }
    let r = 0;
    for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
    return r === 0;
  }

  // ===== Senhas =====
  async function hashPassword(password, saltHex) {
    const salt = saltHex || randomHex(16);
    const hash = await sha256Hex(salt + ':' + password + ':MDP-V3');
    return { hash, salt };
  }

  async function verifyPassword(password, hash, salt) {
    if (!password || !hash || !salt) return false;
    const calc = await sha256Hex(salt + ':' + password + ':MDP-V3');
    return timingSafeEqual(calc, hash);
  }

  // ===== Anti-XSS: escape =====
  function escapeHtml(s) {
    if (s === null || s === undefined) return '';
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/`/g, '&#96;');
  }

  // ===== Sessão (sessionStorage + sign) =====
  const SESSION_KEY = 'mdp_session_v3';
  const SESSION_SECRET = 'mdp-session-signing-key-v3-' + (location.hostname || 'local');
  const SESSION_TTL_MS = 12 * 60 * 60 * 1000;

  async function createSession(user) {
    const nonce = randomHex(16);
    const expires = Date.now() + SESSION_TTL_MS;
    const payload = {
      uid: user.id,
      email: user.email,
      role: user.role,
      nome: user.nome,
      nonce: nonce,
      expires: expires
    };
    const payloadStr = JSON.stringify(payload);
    const sig = await hmacSha256Hex(SESSION_SECRET, payloadStr);
    const token = btoa(payloadStr) + '.' + sig;
    try {
      localStorage.setItem(SESSION_KEY, token);
    } catch (_) {}
    return payload;
  }

  async function getSession() {
    let token;
    try { token = localStorage.getItem(SESSION_KEY); } catch (_) { return null; }
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 2) { clearSession(); return null; }
    let payloadStr;
    try { payloadStr = atob(parts[0]); } catch (_) { clearSession(); return null; }
    const expectedSig = await hmacSha256Hex(SESSION_SECRET, payloadStr);
    if (!timingSafeEqual(expectedSig, parts[1])) { clearSession(); return null; }
    let payload;
    try { payload = JSON.parse(payloadStr); } catch (_) { clearSession(); return null; }
    if (!payload.expires || payload.expires < Date.now()) { clearSession(); return null; }
    return payload;
  }

  function clearSession() {
    try { localStorage.removeItem(SESSION_KEY); } catch (_) {}
  }

  // Guard: redireciona se não logado ou role errado
  async function requireAuth(allowedRoles, redirectTo) {
    const s = await getSession();
    if (!s) {
      location.href = redirectTo || 'login.html';
      throw new Error('unauthenticated');
    }
    if (allowedRoles && allowedRoles.length && allowedRoles.indexOf(s.role) === -1) {
      alert('Acesso negado. Esta área é exclusiva para outro perfil.');
      location.href = 'index.html';
      throw new Error('forbidden');
    }
    return s;
  }

  // ===== Rate limiting (token bucket) =====
  const buckets = {};
  function rateLimit(key, maxPerMinute) {
    const now = Date.now();
    const b = buckets[key] || { tokens: maxPerMinute, last: now };
    const elapsed = now - b.last;
    b.tokens = Math.min(maxPerMinute, b.tokens + (elapsed / 60000) * maxPerMinute);
    b.last = now;
    if (b.tokens < 1) {
      buckets[key] = b;
      return false;
    }
    b.tokens -= 1;
    buckets[key] = b;
    return true;
  }

  // ===== Sanitização extra de input =====
  function cleanInput(s, maxLen) {
    if (s === null || s === undefined) return '';
    s = String(s);
    // remove caracteres de controle exceto tab/newline
    s = s.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, '');
    if (maxLen && s.length > maxLen) s = s.substring(0, maxLen);
    return s.trim();
  }

  // expose
  global.MDPSecurity = {
    sha256Hex, hmacSha256Hex, randomHex, timingSafeEqual,
    hashPassword, verifyPassword,
    escapeHtml, cleanInput,
    createSession, getSession, clearSession, requireAuth,
    rateLimit,
    bufToHex, hexToBuf
  };
})(window);
