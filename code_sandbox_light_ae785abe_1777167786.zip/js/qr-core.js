/* ============================================================
 * qr-core.js — TOTP-like QR rotativo (20s)
 * ============================================================
 * Gera tokens de 16 chars baseados em HMAC-SHA256(secret, slot)
 * onde slot = floor(timestamp_ms / 20000)
 * Tolerância de ±1 slot para drift de relógio
 * ============================================================ */
(function (global) {
  'use strict';

  const SLOT_MS = 20000; // 20 segundos
  const TOKEN_LEN = 16;

  function currentSlot() {
    return Math.floor(Date.now() / SLOT_MS);
  }

  function msUntilNextSlot() {
    return SLOT_MS - (Date.now() % SLOT_MS);
  }

  async function generateToken(secret, slot) {
    if (slot === undefined) slot = currentSlot();
    const hex = await MDPSecurity.hmacSha256Hex(secret, 'MDP-QR-V3:' + slot);
    return hex.substring(0, TOKEN_LEN).toUpperCase();
  }

  // Verifica token com tolerância ±1 slot
  async function verifyToken(secret, token) {
    if (!secret || !token) return false;
    token = String(token).toUpperCase();
    const slot = currentSlot();
    for (let delta = -1; delta <= 1; delta++) {
      const expected = await generateToken(secret, slot + delta);
      if (MDPSecurity.timingSafeEqual(expected, token)) return true;
    }
    return false;
  }

  // Constrói payload completo do QR (com prefixo identificador)
  async function buildQRPayload(secret) {
    const tok = await generateToken(secret);
    return 'MDP-PONTO:' + tok;
  }

  function parseQRPayload(raw) {
    if (!raw) return null;
    const m = String(raw).trim().match(/^MDP-PONTO:([A-F0-9]{16})$/i);
    return m ? m[1].toUpperCase() : null;
  }

  global.MDPQR = {
    SLOT_MS, TOKEN_LEN,
    currentSlot, msUntilNextSlot,
    generateToken, verifyToken,
    buildQRPayload, parseQRPayload
  };
})(window);
