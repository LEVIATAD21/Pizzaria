/* ============================================================
 * painel-gerente.js — Torre de Controle (Gerente / Dono)
 * Funcionalidades:
 * - Kanban de pedidos (avançar status)
 * - Alarme 5min de inatividade do motoboy
 * - QR Ponto rotativo (20s)
 * - Aprovação final de motoboys (após pré-aprovação atendente)
 * - Forçar motoboy offline
 * - Mapa da frota em tempo real
 * - Gestão de produtos
 * ============================================================ */
(function () {
  'use strict';

  let session = null;
  let pedidos = [];
  let users = [];
  let motoboys = [];
  let motoboysDados = [];
  let produtos = [];
  let pingsHistory = {}; // motoboyId -> [{lat,lng,ts}]
  let alarmsAtivos = {}; // motoboyId -> ts
  let lastAlarmSoundAt = 0;

  const ESC = MDPSecurity.escapeHtml;
  const BRL = MDPUI.formatBRL;

  document.getElementById('back-slot').innerHTML = MDPUI.backButton('login.html?staff=1');
  init();

  async function init() {
    session = await MDPSecurity.requireAuth(['gerente', 'dono'], 'login.html?staff=1');
    document.getElementById('user-chip').textContent = '👤 ' + (session.nome || '').split(' ')[0];
    document.getElementById('user-chip').addEventListener('click', logout);
    document.getElementById('role-show').textContent = session.role === 'dono' ? 'Dono' : 'Gerente';

    document.querySelectorAll('.tab').forEach(t => {
      t.addEventListener('click', () => switchTab(t.dataset.tab));
    });

    await refresh();
    setInterval(refresh, 5000);
    setInterval(checkInatividade, 30000); // verifica alarmes a cada 30s
  }

  async function refresh() {
    try {
      await Promise.all([loadPedidos(), loadUsers(), loadMotoboys(), loadProdutos()]);
      renderKanban();
      renderMotoboys();
      renderFrota();
      renderProdutos();
      updateBadges();
      checkInatividade();
    } catch (e) { console.error(e); }
  }

  function switchTab(name) {
    document.querySelectorAll('.tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
    ['kanban','qr','motoboys','frota','produtos'].forEach(p => {
      document.getElementById('panel-' + p).style.display = name === p ? 'block' : 'none';
    });
    if (name === 'qr') startQRDisplay();
    else stopQRDisplay();
    if (name === 'frota') initMapaFrota();
  }

  async function loadPedidos() {
    pedidos = (await MDPApi.list('pedidos', { limit: 300, sort: 'created_at_ms' }))
      .filter(p => !p.deleted)
      .sort((a, b) => (b.created_at_ms || 0) - (a.created_at_ms || 0));
  }
  async function loadUsers() {
    users = (await MDPApi.list('users', { limit: 500 })).filter(u => !u.deleted);
  }
  async function loadMotoboys() {
    motoboysDados = await MDPApi.list('motoboys_dados', { limit: 500 });
    motoboys = users.filter(u => u.role === 'motoboy');
  }
  async function loadProdutos() {
    produtos = (await MDPApi.list('produtos', { limit: 200 })).filter(p => !p.deleted);
  }

  function updateBadges() {
    const ativos = pedidos.filter(p => ['pendente','preparando','pronto','saiu_entrega'].indexOf(p.status) >= 0).length;
    document.getElementById('badge-pedidos').textContent = ativos;
    const aAprovar = users.filter(u => u.role === 'motoboy' && u.status === 'pre_aprovado').length;
    document.getElementById('badge-aprovar').textContent = aAprovar;
  }

  // ===== KANBAN =====
  function renderKanban() {
    const host = document.getElementById('panel-kanban');
    const ativos = pedidos.filter(p => ['pendente','preparando','pronto','saiu_entrega'].indexOf(p.status) >= 0);

    const hoje = new Date(); hoje.setHours(0,0,0,0);
    const pedidosHoje = pedidos.filter(p => p.created_at_ms >= hoje.getTime());
    const entreguesHoje = pedidosHoje.filter(p => p.status === 'entregue');
    const faturamento = entreguesHoje.reduce((s, p) => s + (p.total || 0), 0);
    const ticketMedio = entreguesHoje.length ? faturamento / entreguesHoje.length : 0;
    const motosOnline = motoboysDados.filter(m => m.online).length;

    host.innerHTML = `
      <div class="kpi-row">
        <div class="kpi-card"><div class="label">Pedidos hoje</div><div class="value">${pedidosHoje.length}</div></div>
        <div class="kpi-card"><div class="label">Entregues</div><div class="value">${entreguesHoje.length}</div></div>
        <div class="kpi-card"><div class="label">Faturamento</div><div class="value">${BRL(faturamento)}</div></div>
        <div class="kpi-card"><div class="label">Ticket médio</div><div class="value">${BRL(ticketMedio)}</div></div>
        <div class="kpi-card"><div class="label">Motoboys online</div><div class="value">${motosOnline}</div></div>
      </div>

      <div id="alarms-host"></div>

      <div class="kanban">
        <div class="kcol"><h3>📥 Recebidos <span style="color:#94a3b8">(${ativos.filter(p=>p.status==='pendente').length})</span></h3><div id="col-pendente"></div></div>
        <div class="kcol"><h3>🔥 Preparando <span style="color:#94a3b8">(${ativos.filter(p=>p.status==='preparando').length})</span></h3><div id="col-preparando"></div></div>
        <div class="kcol"><h3>✅ Pronto <span style="color:#94a3b8">(${ativos.filter(p=>p.status==='pronto').length})</span></h3><div id="col-pronto"></div></div>
        <div class="kcol"><h3>🛵 Saiu p/ Entrega <span style="color:#94a3b8">(${ativos.filter(p=>p.status==='saiu_entrega').length})</span></h3><div id="col-saiu"></div></div>
      </div>
    `;

    function renderCol(colId, status) {
      const col = document.getElementById(colId);
      const items = ativos.filter(p => p.status === status);
      if (!items.length) {
        col.innerHTML = '<div style="color:#94a3b8;text-align:center;padding:20px;font-size:13px">Vazio</div>';
        return;
      }
      col.innerHTML = items.map(p => {
        const addr = JSON.parse(p.endereco_json || '{}');
        const isAlerta = p.status === 'saiu_entrega' && alarmsAtivos[p.motoboy_id];
        return `<div class="pcard ${isAlerta ? 'alert' : ''}" onclick="verPedido('${ESC(p.id)}')">
          <div style="display:flex;justify-content:space-between;align-items:center"><b>${ESC(p.numero)}</b><small>${MDPUI.formatTimeAgo(p.created_at_ms)}</small></div>
          <small>${ESC(p.cliente_nome || '')} · ${ESC(p.origem || 'app')}</small>
          <small>${ESC(addr.bairro || '')}</small>
          <small><b>${BRL(p.total || 0)}</b></small>
          ${p.motoboy_id ? '<small>🛵 ' + ESC(getMotoboyNome(p.motoboy_id)) + '</small>' : ''}
        </div>`;
      }).join('');
    }
    renderCol('col-pendente', 'pendente');
    renderCol('col-preparando', 'preparando');
    renderCol('col-pronto', 'pronto');
    renderCol('col-saiu', 'saiu_entrega');

    renderAlarms();
  }

  function getMotoboyNome(uid) {
    const u = users.find(x => x.id === uid);
    return u ? u.nome : '?';
  }

  // ===== Pedido modal =====
  window.verPedido = function (id) {
    const p = pedidos.find(x => x.id === id);
    if (!p) return;
    const addr = JSON.parse(p.endereco_json || '{}');
    const itens = JSON.parse(p.itens_json || '[]');
    const motoboysOnline = motoboys.filter(m => m.status === 'ativo' && motoboysDados.find(d => d.user_id === m.id && d.online));

    showModal(`
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
        <h2>Pedido ${ESC(p.numero)}</h2>
        <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">✕</button>
      </div>
      <div class="mdp-card" style="background:#f9fafb">
        <b>${ESC(p.cliente_nome || '')}</b> ${p.cliente_telefone ? '· 📞 ' + ESC(MDPValidators.maskTelefone(p.cliente_telefone)) : ''}<br>
        <small>${ESC(addr.rua||'')}, ${ESC(addr.numero||'')} ${addr.complemento ? '— '+ESC(addr.complemento) : ''}</small><br>
        <small>${ESC(addr.bairro||'')}, ${ESC(addr.cidade||'')}</small>
      </div>
      <h3 style="margin-top:10px">Itens</h3>
      ${itens.map(i => '<div style="display:flex;justify-content:space-between;padding:4px 0"><span>'+i.qty+'× '+ESC(i.nome)+'</span><b>'+BRL(i.subtotal)+'</b></div>').join('')}
      <div style="border-top:1px solid var(--border);margin-top:8px;padding-top:8px">
        <div style="display:flex;justify-content:space-between"><span>Subtotal</span><b>${BRL(p.subtotal)}</b></div>
        <div style="display:flex;justify-content:space-between"><span>Entrega</span><b>${BRL(p.taxa_entrega)}</b></div>
        <div style="display:flex;justify-content:space-between;font-size:18px"><span>Total</span><b style="color:var(--primary-dark)">${BRL(p.total)}</b></div>
        <div>Pagamento: <b>${ESC(p.forma_pagamento)}</b></div>
        ${p.observacoes ? '<div style="margin-top:6px;padding:8px;background:#fef3c7;border-radius:8px;font-size:13px">📝 '+ESC(p.observacoes)+'</div>' : ''}
      </div>
      <h3 style="margin-top:14px">Avançar status</h3>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${p.status==='pendente' ? '<button class="mdp-btn warn" onclick="avancar(\''+ESC(p.id)+'\',\'preparando\')">▶ Iniciar preparo</button>' : ''}
        ${p.status==='preparando' ? '<button class="mdp-btn success" onclick="avancar(\''+ESC(p.id)+'\',\'pronto\')">✓ Marcar Pronto</button>' : ''}
        ${p.status==='pronto' && !p.motoboy_id ? `
          <select id="atribuir-mb" class="mdp-select" style="flex:1">
            <option value="">Atribuir motoboy…</option>
            ${motoboysOnline.map(m=>'<option value="'+ESC(m.id)+'">'+ESC(m.nome)+'</option>').join('')}
          </select>
          <button class="mdp-btn" onclick="atribuirMotoboy('${ESC(p.id)}')">Saiu p/ entrega</button>
        ` : ''}
        ${p.status==='saiu_entrega' ? '<button class="mdp-btn success" onclick="avancar(\''+ESC(p.id)+'\',\'entregue\')">✓ Marcar Entregue</button>' : ''}
        ${['pendente','preparando','pronto'].indexOf(p.status)>=0 ? '<button class="mdp-btn danger" onclick="cancelar(\''+ESC(p.id)+'\')">Cancelar pedido</button>' : ''}
      </div>
    `);
  };

  window.avancar = async function (id, novoStatus) {
    const upd = { status: novoStatus };
    if (novoStatus === 'saiu_entrega') upd.saiu_entrega_ms = Date.now();
    if (novoStatus === 'entregue') upd.entregue_ms = Date.now();
    try {
      await MDPApi.patch('pedidos', id, upd);
      MDPUI.toast('Status atualizado!', 'success');
      closeModal();
      refresh();
    } catch (e) { console.error(e); MDPUI.toast('Erro', 'error'); }
  };
  window.atribuirMotoboy = async function (id) {
    const sel = document.getElementById('atribuir-mb').value;
    if (!sel) return MDPUI.toast('Selecione um motoboy', 'error');
    try {
      await MDPApi.patch('pedidos', id, { motoboy_id: sel, status: 'saiu_entrega', saiu_entrega_ms: Date.now() });
      MDPUI.toast('Motoboy atribuído!', 'success');
      closeModal(); refresh();
    } catch (e) { MDPUI.toast('Erro', 'error'); }
  };
  window.cancelar = async function (id) {
    if (!await MDPUI.confirmDialog('Cancelar este pedido?')) return;
    await MDPApi.patch('pedidos', id, { status: 'cancelado' });
    MDPUI.toast('Cancelado', 'warn'); closeModal(); refresh();
  };

  // ===== Alarme 5 min =====
  function checkInatividade() {
    const agora = Date.now();
    const TRESHOLD = 5 * 60 * 1000;

    motoboysDados.forEach(m => {
      if (!m.online || !m.user_id) return;
      const pedidoSaiu = pedidos.find(p => p.motoboy_id === m.user_id && p.status === 'saiu_entrega');
      if (!pedidoSaiu) { delete alarmsAtivos[m.user_id]; return; }

      // Inativo se ultimo_ping_ms + 5min < agora E há entrega ativa
      if (m.ultimo_ping_ms && (agora - m.ultimo_ping_ms) > TRESHOLD) {
        if (!alarmsAtivos[m.user_id]) {
          alarmsAtivos[m.user_id] = agora;
          tocarAlarme();
        }
      } else if (m.ultima_lat && m.ultima_lng) {
        // Verifica deslocamento (haversine entre 5min atrás)
        const hist = pingsHistory[m.user_id] || [];
        hist.push({ lat: m.ultima_lat, lng: m.ultima_lng, ts: m.ultimo_ping_ms || agora });
        const limite = agora - TRESHOLD;
        const antigos = hist.filter(p => p.ts < limite);
        const novos = hist.filter(p => p.ts >= limite);
        // mantém histórico curto
        pingsHistory[m.user_id] = hist.slice(-30);

        if (antigos.length && novos.length) {
          const dist = haversine(antigos[antigos.length-1], novos[novos.length-1]);
          if (dist < 10) { // <10 metros em 5 min = parado
            if (!alarmsAtivos[m.user_id]) {
              alarmsAtivos[m.user_id] = agora;
              tocarAlarme();
            }
          } else {
            delete alarmsAtivos[m.user_id];
          }
        }
      }
    });
    renderAlarms();
  }

  function haversine(p1, p2) {
    const R = 6371000;
    const toRad = d => d * Math.PI / 180;
    const dLat = toRad(p2.lat - p1.lat);
    const dLng = toRad(p2.lng - p1.lng);
    const a = Math.sin(dLat/2)**2 + Math.cos(toRad(p1.lat))*Math.cos(toRad(p2.lat))*Math.sin(dLng/2)**2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  function tocarAlarme() {
    const now = Date.now();
    if (now - lastAlarmSoundAt < 30000) return; // evita spam
    lastAlarmSoundAt = now;
    try { document.getElementById('alarm-sound').play().catch(()=>{}); } catch (_) {}
  }

  function renderAlarms() {
    const host = document.getElementById('alarms-host');
    if (!host) return;
    const lista = Object.keys(alarmsAtivos);
    if (!lista.length) { host.innerHTML = ''; return; }
    host.innerHTML = `<div class="alarms-panel">
      <h3 style="color:#9a3412">🚨 Alerta: motoboys parados há mais de 5 minutos</h3>
      ${lista.map(uid => {
        const u = users.find(x => x.id === uid);
        if (!u) return '';
        const tel = u.telefone || '';
        const wa = 'https://wa.me/55' + tel + '?text=' + encodeURIComponent('Olá ' + (u.nome||'').split(' ')[0] + ', tudo bem? Está parado há alguns minutos. Precisa de ajuda?');
        return `<div class="alarm-item">
          <div><b>${ESC(u.nome)}</b> · há ${MDPUI.formatTimeAgo(alarmsAtivos[uid])}</div>
          <a href="${wa}" target="_blank" class="mdp-btn warn" style="padding:6px 12px;font-size:13px;text-decoration:none">📱 Acionar WhatsApp</a>
        </div>`;
      }).join('')}
    </div>`;
  }

  // ===== QR Ponto =====
  let qrTimer = null;
  function startQRDisplay() {
    const host = document.getElementById('panel-qr');
    host.innerHTML = `
      <h2>🔁 QR Code de Ponto (Check-in / Check-out)</h2>
      <p style="color:var(--text-muted);margin-bottom:14px">Os motoboys devem escanear este QR no balcão para entrar e sair de turno. O código muda a cada 20 segundos. <b>Mesmo QR serve para entrada e saída.</b></p>

      <div class="qr-display">
        <div class="qr-canvas" id="qr-canvas-host"></div>
        <div class="qr-progress"><div id="qr-progress-bar" style="width:100%"></div></div>
        <div style="font-family:monospace;font-size:14px;color:var(--text-muted)">Token: <span id="qr-token-text">…</span></div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:6px">Próxima rotação em <span id="qr-countdown">…</span> seg</div>
        <button class="mdp-btn" style="margin-top:16px" onclick="qrFullscreen()">🔍 Modo tela cheia</button>
      </div>
    `;
    drawQR();
    if (qrTimer) clearInterval(qrTimer);
    qrTimer = setInterval(drawQR, 250);
  }
  function stopQRDisplay() { if (qrTimer) { clearInterval(qrTimer); qrTimer = null; } }

  let lastSlot = -1;
  async function drawQR() {
    const slot = MDPQR.currentSlot();
    const host = document.getElementById('qr-canvas-host');
    if (!host) return;
    if (slot !== lastSlot) {
      lastSlot = slot;
      const secret = await MDPApi.getQRSecret();
      if (!secret) return;
      const payload = await MDPQR.buildQRPayload(secret);
      host.innerHTML = '';
      const canvas = document.createElement('canvas');
      host.appendChild(canvas);
      QRCode.toCanvas(canvas, payload, { width: 280, margin: 1, color: { dark:'#1f2937', light:'#fff' } });
      document.getElementById('qr-token-text').textContent = payload;
    }
    // progress
    const remain = MDPQR.msUntilNextSlot();
    const pct = (remain / MDPQR.SLOT_MS) * 100;
    const bar = document.getElementById('qr-progress-bar');
    if (bar) bar.style.width = pct + '%';
    const cd = document.getElementById('qr-countdown');
    if (cd) cd.textContent = Math.ceil(remain / 1000);
  }

  window.qrFullscreen = async function () {
    const w = window.open('', '_blank', 'width=720,height=900');
    if (!w) { MDPUI.toast('Permita popups', 'warn'); return; }
    w.document.write(`
      <html><head><title>QR Ponto</title>
      <script src="https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js"><\/script>
      <style>body{margin:0;background:#1f2937;display:flex;align-items:center;justify-content:center;min-height:100vh;font-family:sans-serif;color:#fff}
      .box{text-align:center}.box canvas{background:#fff;padding:24px;border-radius:24px}
      h1{font-size:36px}p{font-size:18px;color:#9ca3af}</style>
      </head><body>
      <div class="box">
        <h1>📱 ESCANEIE PARA BATER PONTO</h1>
        <canvas id="qrf"></canvas>
        <p>Este código muda a cada 20 segundos</p>
        <p id="cd" style="font-size:24px;color:#10b981"></p>
      </div>
      <script>
        const SECRET = '${(await MDPApi.getQRSecret()) || ''}';
        async function hmac(k,m){const e=new TextEncoder();const ck=await crypto.subtle.importKey('raw',e.encode(k),{name:'HMAC',hash:'SHA-256'},false,['sign']);const s=await crypto.subtle.sign('HMAC',ck,e.encode(m));return Array.from(new Uint8Array(s)).map(b=>b.toString(16).padStart(2,'0')).join('').toUpperCase()}
        async function tick(){const slot=Math.floor(Date.now()/20000);const tok=(await hmac(SECRET,'MDP-QR-V3:'+slot)).substring(0,16);QRCode.toCanvas(document.getElementById('qrf'),'MDP-PONTO:'+tok,{width:520,margin:1});document.getElementById('cd').textContent='Próximo em '+Math.ceil((20000-(Date.now()%20000))/1000)+'s'}
        tick();setInterval(tick,250);
      <\/script></body></html>
    `);
  };

  // ===== Motoboys =====
  function renderMotoboys() {
    const host = document.getElementById('panel-motoboys');
    if (!host) return;

    const grupos = {
      pre_aprovado: motoboys.filter(m => m.status === 'pre_aprovado'),
      ativo: motoboys.filter(m => m.status === 'ativo'),
      pendente: motoboys.filter(m => m.status === 'pendente'),
      reprovado: motoboys.filter(m => m.status === 'reprovado')
    };

    host.innerHTML = `
      <h2 style="margin-bottom:12px">Gestão de motoboys</h2>

      ${grupos.pre_aprovado.length ? `
        <div class="mdp-card" style="background:#fef3c7;border-color:#fcd34d">
          <h3 style="color:#92400e">⏳ Aguardando sua aprovação final (${grupos.pre_aprovado.length})</h3>
          ${grupos.pre_aprovado.map(u => motoboyRow(u, true)).join('')}
        </div>` : ''}

      <div class="mdp-card">
        <h3>✅ Motoboys ativos (${grupos.ativo.length})</h3>
        ${grupos.ativo.length ? grupos.ativo.map(u => motoboyRow(u, false)).join('') : '<p style="color:var(--text-muted)">Nenhum motoboy ativo.</p>'}
      </div>

      ${grupos.pendente.length ? `
        <div class="mdp-card">
          <h3>⏸ Aguardando pré-aprovação do atendente (${grupos.pendente.length})</h3>
          ${grupos.pendente.map(u => '<div class="motoboy-row"><img src="" onerror="this.style.opacity=.3"><div><b>'+ESC(u.nome)+'</b><br><small>'+ESC(u.email)+'</small></div><span class="badge pendente">Aguardando atendente</span></div>').join('')}
        </div>` : ''}

      ${grupos.reprovado.length ? `
        <div class="mdp-card" style="background:#fef2f2">
          <h3 style="color:#991b1b">✗ Reprovados (${grupos.reprovado.length})</h3>
          ${grupos.reprovado.map(u => '<div class="motoboy-row"><img src=""><div><b>'+ESC(u.nome)+'</b><br><small>Motivo: '+ESC(u.reprovacao_motivo||'-')+'</small></div><button class="mdp-btn secondary" onclick="reativar(\''+ESC(u.id)+'\')">Reativar</button></div>').join('')}
        </div>` : ''}
    `;
  }

  function motoboyRow(u, isPendenteFinal) {
    const d = motoboysDados.find(x => x.user_id === u.id) || {};
    const isOnline = d.online;
    const tel = u.telefone || '';
    const wa = tel ? 'https://wa.me/55' + tel : '#';
    return `<div class="motoboy-row">
      <img src="${ESC(d.foto_3x4_data || '')}" onerror="this.style.opacity=.3">
      <div>
        <b>${ESC(u.nome)}</b>
        ${isOnline ? '<span class="badge online" style="margin-left:6px">ONLINE</span>' : (u.status==='ativo' ? '<span class="badge offline" style="margin-left:6px">OFFLINE</span>' : '')}
        <br>
        <small>📞 ${ESC(MDPValidators.maskTelefone(tel))} · 🪪 CPF ${ESC(MDPValidators.maskCPFHidden(d.cpf||''))}</small><br>
        <small>🛵 ${ESC(d.moto_modelo||'')} · Placa <b>${ESC(MDPValidators.maskPlaca(d.placa||''))}</b></small>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px;align-items:flex-end">
        ${d.foto_cnh_data ? '<button class="mdp-btn secondary" style="padding:6px 12px;font-size:12px" onclick="verCNH(\''+ESC(u.id)+'\')">👁 CNH</button>' : ''}
        ${tel ? '<a href="'+wa+'" target="_blank" class="mdp-btn" style="padding:6px 12px;font-size:12px;background:#25d366">WhatsApp</a>' : ''}
        ${isPendenteFinal ? '<button class="mdp-btn success" style="padding:8px 14px" onclick="aprovarFinal(\''+ESC(u.id)+'\')">✓ Aprovar FINAL</button>' : ''}
        ${isPendenteFinal ? '<button class="mdp-btn danger" style="padding:6px 12px;font-size:12px" onclick="reprovarFinal(\''+ESC(u.id)+'\')">✗ Reprovar</button>' : ''}
        ${u.status==='ativo' && isOnline ? '<button class="mdp-btn warn" style="padding:6px 12px;font-size:12px" onclick="forcarOffline(\''+ESC(u.id)+'\')">⏹ Forçar offline</button>' : ''}
      </div>
    </div>`;
  }

  window.verCNH = function (uid) {
    const d = motoboysDados.find(x => x.user_id === uid);
    if (!d || !d.foto_cnh_data) return MDPUI.toast('CNH não disponível', 'warn');
    const w = window.open('', '_blank');
    w.document.write('<html><body style="margin:0;background:#000;display:flex;align-items:center;justify-content:center;min-height:100vh"><img src="'+d.foto_cnh_data+'" style="max-width:100%;max-height:100vh"></body></html>');
  };

  window.aprovarFinal = async function (uid) {
    const ok = await MDPUI.confirmDialog('Aprovar definitivamente este motoboy? Ele poderá começar a trabalhar.');
    if (!ok) return;
    await MDPApi.patch('users', uid, { status: 'ativo', aprovado_por: session.uid });
    await MDPApi.create('aprovacoes_log', {
      id: 'apr-' + MDPSecurity.randomHex(8),
      motoboy_id: uid, acao: 'aprovacao_final',
      executado_por: session.uid, executado_por_nome: session.nome,
      executado_por_role: session.role, timestamp_ms: Date.now()
    });
    MDPUI.toast('Aprovado! Motoboy liberado para trabalhar.', 'success');
    refresh();
  };

  window.reprovarFinal = async function (uid) {
    const motivo = await MDPUI.promptDialog('Motivo da reprovação final:');
    if (!motivo) return;
    await MDPApi.patch('users', uid, { status: 'reprovado', reprovacao_motivo: MDPSecurity.cleanInput(motivo, 200) });
    await MDPApi.create('aprovacoes_log', {
      id: 'apr-' + MDPSecurity.randomHex(8),
      motoboy_id: uid, acao: 'reprovacao', motivo: motivo,
      executado_por: session.uid, executado_por_nome: session.nome,
      executado_por_role: session.role, timestamp_ms: Date.now()
    });
    MDPUI.toast('Reprovado.', 'warn');
    refresh();
  };

  window.reativar = async function (uid) {
    const ok = await MDPUI.confirmDialog('Reativar este motoboy como ativo?');
    if (!ok) return;
    await MDPApi.patch('users', uid, { status: 'ativo', reprovacao_motivo: '' });
    await MDPApi.create('aprovacoes_log', {
      id: 'apr-' + MDPSecurity.randomHex(8),
      motoboy_id: uid, acao: 'reativacao',
      executado_por: session.uid, executado_por_nome: session.nome,
      executado_por_role: session.role, timestamp_ms: Date.now()
    });
    MDPUI.toast('Motoboy reativado.', 'success'); refresh();
  };

  window.forcarOffline = async function (uid) {
    const motivo = await MDPUI.promptDialog('Motivo (sem trabalho, urgência, etc):', 'Forçado offline pelo gerente');
    if (motivo === null) return;
    const d = motoboysDados.find(x => x.user_id === uid);
    if (!d) return;
    await MDPApi.patch('motoboys_dados', d.id, { online: false, turno_inicio_ms: 0 });
    await MDPApi.create('ponto_log', {
      id: 'pl-' + MDPSecurity.randomHex(8),
      motoboy_id: uid, motoboy_nome: getMotoboyNome(uid),
      acao: 'forcado_offline', motivo: motivo,
      executado_por: session.uid, executado_por_nome: session.nome,
      timestamp_ms: Date.now()
    });
    MDPUI.toast('Motoboy colocado offline.', 'success'); refresh();
  };

  // ===== Mapa Frota =====
  let mapaFrota = null, fleetMarkers = {};
  function initMapaFrota() {
    const el = document.getElementById('panel-frota');
    el.innerHTML = `
      <h2 style="margin-bottom:12px">🗺️ Frota ao vivo</h2>
      <p style="color:var(--text-muted);margin-bottom:10px">Posição em tempo real dos motoboys online (atualiza a cada 5s).</p>
      <div id="map-frota"></div>`;
    if (mapaFrota) { mapaFrota.remove(); mapaFrota = null; fleetMarkers = {}; }
    mapaFrota = L.map('map-frota').setView([-22.7160, -43.5550], 14); // Queimados
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OSM' }).addTo(mapaFrota);
    // Loja
    L.marker([-22.7160, -43.5550], {
      icon: L.divIcon({ html:'<div style="font-size:36px">🏪</div>', className:'', iconSize:[40,40], iconAnchor:[20,20] })
    }).addTo(mapaFrota).bindPopup('<b>Mania de Pizza</b>');
    renderFrota();
  }
  function renderFrota() {
    if (!mapaFrota) return;
    const online = motoboysDados.filter(m => m.online && m.ultima_lat && m.ultima_lng);
    online.forEach(m => {
      const u = users.find(x => x.id === m.user_id);
      const nome = u ? u.nome : '?';
      const popup = '<b>🛵 ' + ESC(nome) + '</b><br>Última atualização: ' + MDPUI.formatTimeAgo(m.ultimo_ping_ms || 0);
      if (fleetMarkers[m.user_id]) {
        fleetMarkers[m.user_id].setLatLng([m.ultima_lat, m.ultima_lng]).setPopupContent(popup);
      } else {
        fleetMarkers[m.user_id] = L.marker([m.ultima_lat, m.ultima_lng], {
          icon: L.divIcon({ html:'<div style="font-size:30px">🛵</div>', className:'', iconSize:[36,36], iconAnchor:[18,18] })
        }).addTo(mapaFrota).bindPopup(popup);
      }
    });
    // Remove markers de quem ficou offline
    Object.keys(fleetMarkers).forEach(uid => {
      if (!online.find(m => m.user_id === uid)) {
        mapaFrota.removeLayer(fleetMarkers[uid]);
        delete fleetMarkers[uid];
      }
    });
  }

  // ===== Produtos =====
  function renderProdutos() {
    const host = document.getElementById('panel-produtos');
    if (!host) return;
    host.innerHTML = `
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h2>🍕 Produtos do cardápio</h2>
        <button class="mdp-btn" onclick="adicionarProduto()">+ Novo produto</button>
      </div>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:12px">
        ${produtos.map(p => `
          <div class="mdp-card" style="margin:0">
            <div style="display:flex;gap:10px">
              <img src="${ESC(p.foto_url||'')}" style="width:70px;height:70px;border-radius:10px;object-fit:cover" onerror="this.style.opacity=.3">
              <div style="flex:1">
                <b>${ESC(p.nome)}</b><br>
                <small style="color:var(--text-muted)">${ESC(p.categoria)} · <b>${BRL(p.preco)}</b></small>
                <div style="margin-top:6px">
                  ${p.ativo ? '<button class="mdp-btn warn" style="padding:4px 10px;font-size:12px" onclick="pausar(\''+ESC(p.id)+'\')">⏸ Pausar</button>' : '<button class="mdp-btn success" style="padding:4px 10px;font-size:12px" onclick="ativar(\''+ESC(p.id)+'\')">▶ Ativar</button>'}
                </div>
              </div>
            </div>
          </div>`).join('')}
      </div>
    `;
  }

  window.pausar = async function (id) {
    await MDPApi.patch('produtos', id, { ativo: false });
    MDPUI.toast('Produto pausado.', 'warn'); refresh();
  };
  window.ativar = async function (id) {
    await MDPApi.patch('produtos', id, { ativo: true });
    MDPUI.toast('Produto ativado.', 'success'); refresh();
  };
  window.adicionarProduto = async function () {
    const nome = await MDPUI.promptDialog('Nome do produto:');
    if (!nome) return;
    const desc = await MDPUI.promptDialog('Descrição:');
    const preco = parseFloat(await MDPUI.promptDialog('Preço (R$):', '0'));
    if (!preco || preco <= 0) return MDPUI.toast('Preço inválido', 'error');
    const cat = await MDPUI.promptDialog('Categoria (pizza-salgada, pizza-doce, bebida, sobremesa):', 'pizza-salgada');
    const foto = await MDPUI.promptDialog('URL da foto:', 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600');
    await MDPApi.create('produtos', {
      id: 'prod-' + MDPSecurity.randomHex(6),
      nome: MDPSecurity.cleanInput(nome, 80),
      descricao: MDPSecurity.cleanInput(desc, 200),
      categoria: cat,
      preco: preco,
      foto_url: foto || '',
      ativo: true
    });
    MDPUI.toast('Produto criado!', 'success'); refresh();
  };

  // ===== Modal =====
  window.showModal = function (html) {
    closeModal();
    const bg = document.createElement('div');
    bg.id = 'modal-bg';
    bg.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:200;display:flex;align-items:center;justify-content:center;padding:20px';
    bg.addEventListener('click', e => { if (e.target === bg) closeModal(); });
    const m = document.createElement('div');
    m.style.cssText = 'background:#fff;border-radius:18px;max-width:600px;width:100%;max-height:90vh;overflow-y:auto;padding:22px';
    m.innerHTML = html;
    bg.appendChild(m);
    document.body.appendChild(bg);
  };
  window.closeModal = function () { const m = document.getElementById('modal-bg'); if (m) m.remove(); };

  function logout() {
    if (confirm('Sair do painel?')) {
      MDPSecurity.clearSession();
      location.href = 'index.html';
    }
  }
})();
