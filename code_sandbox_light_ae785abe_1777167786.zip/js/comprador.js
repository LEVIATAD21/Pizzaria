/* ============================================================
 * comprador.js — App do Cliente
 * ============================================================ */
(function () {
  'use strict';

  let session = null;
  let produtos = [];
  let categoriaAtiva = 'pizza-salgada';
  let cart = []; // { id, nome, preco, foto_url, qty }
  let enderecos = [];
  let pedidoAtivo = null;
  let pollTimer = null;

  const ESC = MDPSecurity.escapeHtml;
  const BRL = MDPUI.formatBRL;
  const TAXA_ENTREGA = 6.0;

  document.getElementById('back-slot').innerHTML = MDPUI.backButton('index.html');

  init();

  async function init() {
    session = await MDPSecurity.requireAuth(['cliente'], 'cliente-entrada.html');
    document.getElementById('user-chip').textContent = '👤 ' + (session.nome || '').split(' ')[0];

    // Carrega carrinho do localStorage
    try {
      const raw = localStorage.getItem('mdp_cart_' + session.uid);
      if (raw) cart = JSON.parse(raw);
    } catch (_) {}

    await Promise.all([loadProdutos(), loadEnderecos(), checkPedidoAtivo()]);
    renderTabs();
    renderProdutos();
    renderCart();
  }

  async function loadProdutos() {
    produtos = await MDPApi.list('produtos', { limit: 200 });
    produtos = produtos.filter(p => p.ativo !== false && !p.deleted);
  }

  async function loadEnderecos() {
    const all = await MDPApi.list('enderecos', { limit: 200 });
    enderecos = all.filter(e => e.user_id === session.uid && !e.deleted);
  }

  async function checkPedidoAtivo() {
    const all = await MDPApi.list('pedidos', { limit: 100, sort: 'created_at_ms' });
    const meus = all.filter(p =>
      p.cliente_id === session.uid && !p.deleted &&
      ['pendente', 'preparando', 'pronto', 'saiu_entrega'].indexOf(p.status) >= 0
    );
    if (meus.length) {
      pedidoAtivo = meus[meus.length - 1];
      renderBannerAtivo();
      startPolling();
    }
  }

  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(async function () {
      if (!pedidoAtivo) return;
      try {
        const fresh = await MDPApi.get('pedidos', pedidoAtivo.id);
        if (fresh) {
          pedidoAtivo = fresh;
          if (['entregue','cancelado'].indexOf(fresh.status) >= 0) {
            clearInterval(pollTimer);
            document.getElementById('pedido-ativo-banner').style.display = 'none';
            MDPUI.toast(fresh.status === 'entregue' ? '🎉 Pedido entregue!' : 'Pedido cancelado', fresh.status === 'entregue' ? 'success' : 'warn');
            pedidoAtivo = null;
            return;
          }
          updateStatusModalIfOpen();
          renderBannerAtivo();
          if (fresh.status === 'saiu_entrega' && fresh.motoboy_id) {
            await refreshMotoboyPos();
          }
        }
      } catch (_) {}
    }, 5000);
  }

  async function refreshMotoboyPos() {
    if (!pedidoAtivo || !pedidoAtivo.motoboy_id) return;
    try {
      const list = await MDPApi.list('motoboys_dados', { limit: 100 });
      const mb = list.find(m => m.user_id === pedidoAtivo.motoboy_id);
      if (mb && mb.ultima_lat && mb.ultima_lng) {
        updateMotoboyMap(mb);
        // Verifica inatividade (5 min)
        if (mb.ultimo_ping_ms && Date.now() - mb.ultimo_ping_ms > 5 * 60 * 1000) {
          showInatividadeMsg();
        }
      }
    } catch (_) {}
  }

  let mapaRastreio = null;
  let motoMarker = null;
  function updateMotoboyMap(mb) {
    const el = document.getElementById('map-rastreio');
    if (!el) return;
    if (!mapaRastreio) {
      mapaRastreio = L.map(el).setView([mb.ultima_lat, mb.ultima_lng], 15);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OSM', maxZoom: 19
      }).addTo(mapaRastreio);
      const motoIcon = L.divIcon({
        html: '<div style="font-size:30px">🛵</div>',
        className: '', iconSize: [36, 36], iconAnchor: [18, 18]
      });
      motoMarker = L.marker([mb.ultima_lat, mb.ultima_lng], { icon: motoIcon }).addTo(mapaRastreio);
    } else {
      motoMarker.setLatLng([mb.ultima_lat, mb.ultima_lng]);
      mapaRastreio.panTo([mb.ultima_lat, mb.ultima_lng], { animate: true });
    }
  }

  function showInatividadeMsg() {
    const box = document.getElementById('inatividade-msg');
    if (box) {
      box.innerHTML = '🚦 Seu pedido está em uma rota com trânsito intenso, mas o entregador já está retomando!';
      box.style.display = 'block';
    }
  }

  function renderTabs() {
    const cats = [
      { id: 'pizza-salgada', label: '🍕 Salgadas' },
      { id: 'pizza-doce', label: '🍫 Doces' },
      { id: 'bebida', label: '🥤 Bebidas' },
      { id: 'sobremesa', label: '🍨 Sobremesas' }
    ];
    document.getElementById('menu-tabs').innerHTML = cats.map(c =>
      '<button class="menu-tab' + (c.id === categoriaAtiva ? ' active' : '') + '" data-cat="' + c.id + '">' + c.label + '</button>'
    ).join('');
    document.querySelectorAll('.menu-tab').forEach(b => {
      b.addEventListener('click', () => {
        categoriaAtiva = b.dataset.cat;
        renderTabs();
        renderProdutos();
      });
    });
  }

  function renderProdutos() {
    const list = produtos.filter(p => p.categoria === categoriaAtiva);
    const grid = document.getElementById('product-grid');
    if (!list.length) {
      grid.innerHTML = '<div class="mdp-empty"><div class="icon">🍴</div>Nenhum item nesta categoria.</div>';
      return;
    }
    grid.innerHTML = list.map(p =>
      '<div class="product-card">' +
        '<div class="info">' +
          '<h3>' + ESC(p.nome) + '</h3>' +
          '<div class="desc">' + ESC(p.descricao || '') + '</div>' +
          '<div class="preco">' + BRL(p.preco) + '</div>' +
          '<button class="add-btn" data-id="' + ESC(p.id) + '">+ Adicionar</button>' +
        '</div>' +
        '<img src="' + ESC(p.foto_url || '') + '" alt="' + ESC(p.nome) + '" loading="lazy" onerror="this.style.background=\'#fee\';this.src=\'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Ctext y=%2270%22 font-size=%2270%22%3E🍕%3C/text%3E%3C/svg%3E\'">' +
      '</div>'
    ).join('');
    document.querySelectorAll('.add-btn').forEach(b => {
      b.addEventListener('click', () => addToCart(b.dataset.id));
    });
  }

  function addToCart(id) {
    const p = produtos.find(x => x.id === id);
    if (!p) return;
    const ex = cart.find(c => c.id === id);
    if (ex) ex.qty += 1;
    else cart.push({ id: p.id, nome: p.nome, preco: p.preco, foto_url: p.foto_url, qty: 1 });
    saveCart(); renderCart();
    MDPUI.toast('Adicionado: ' + p.nome, 'success');
  }

  function saveCart() {
    try { localStorage.setItem('mdp_cart_' + session.uid, JSON.stringify(cart)); } catch (_) {}
  }

  function cartTotal() { return cart.reduce((s, i) => s + i.preco * i.qty, 0); }
  function cartCount() { return cart.reduce((s, i) => s + i.qty, 0); }

  function renderCart() {
    const bar = document.getElementById('cart-bar');
    if (!cart.length) { bar.classList.add('hidden'); return; }
    bar.classList.remove('hidden');
    document.getElementById('cart-count').textContent = cartCount() + ' item' + (cartCount() > 1 ? 's' : '');
    document.getElementById('cart-total').textContent = BRL(cartTotal());
  }

  // ===== Modal: Carrinho =====
  window.abrirCarrinho = function () {
    if (!cart.length) return MDPUI.toast('Carrinho vazio', 'info');
    showModal(`
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h2>Seu pedido</h2>
        <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">✕</button>
      </div>
      <div id="cart-items"></div>
      <div style="border-top:2px solid var(--border);margin-top:12px;padding-top:12px;display:flex;justify-content:space-between"><span>Subtotal</span><b id="cart-subtotal"></b></div>
      <div style="display:flex;justify-content:space-between"><span>Taxa de entrega</span><b>${BRL(TAXA_ENTREGA)}</b></div>
      <div style="display:flex;justify-content:space-between;font-size:18px;margin-top:6px"><span>Total</span><b id="cart-final" style="color:var(--primary-dark)"></b></div>
      <button class="mdp-btn full lg" style="margin-top:16px" onclick="abrirCheckout()">Finalizar pedido →</button>
    `);
    renderCartItems();
  };

  function renderCartItems() {
    const host = document.getElementById('cart-items');
    if (!host) return;
    host.innerHTML = cart.map(i =>
      '<div class="cart-item">' +
        '<img src="' + ESC(i.foto_url || '') + '" alt="" onerror="this.style.opacity=\'.3\'">' +
        '<div class="info"><b>' + ESC(i.nome) + '</b><div class="preco">' + BRL(i.preco) + '</div></div>' +
        '<div class="qty"><button data-act="dec" data-id="' + ESC(i.id) + '">−</button>' +
          '<span>' + i.qty + '</span>' +
          '<button data-act="inc" data-id="' + ESC(i.id) + '">+</button></div>' +
      '</div>'
    ).join('');
    document.getElementById('cart-subtotal').textContent = BRL(cartTotal());
    document.getElementById('cart-final').textContent = BRL(cartTotal() + TAXA_ENTREGA);
    host.querySelectorAll('button').forEach(b => {
      b.addEventListener('click', () => {
        const id = b.dataset.id, act = b.dataset.act;
        const it = cart.find(x => x.id === id);
        if (!it) return;
        if (act === 'inc') it.qty++;
        else { it.qty--; if (it.qty <= 0) cart = cart.filter(c => c.id !== id); }
        saveCart(); renderCartItems(); renderCart();
        if (!cart.length) closeModal();
      });
    });
  }

  // ===== Modal: Checkout =====
  window.abrirCheckout = async function () {
    if (!cart.length) return;
    if (!enderecos.length) {
      const ok = await MDPUI.confirmDialog('Você ainda não tem endereço cadastrado. Deseja cadastrar agora?');
      if (ok) location.href = 'cadastro-cliente.html';
      return;
    }
    const principal = enderecos.find(e => e.principal) || enderecos[0];
    let selectedId = principal.id;

    showModal(`
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h2>Finalizar pedido</h2>
        <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">✕</button>
      </div>
      <h3>Endereço de entrega</h3>
      <div id="addr-list"></div>
      <h3 style="margin-top:14px">Forma de pagamento</h3>
      <select id="forma_pgto" class="mdp-select">
        <option value="pix">PIX</option>
        <option value="credito">Cartão de Crédito (na entrega)</option>
        <option value="debito">Cartão de Débito (na entrega)</option>
        <option value="dinheiro">Dinheiro</option>
      </select>
      <div id="troco-field" style="display:none;margin-top:10px">
        <label>Troco para:</label>
        <input type="number" id="troco_para" class="mdp-input" min="0" step="1" placeholder="Ex: 100">
      </div>
      <h3 style="margin-top:14px">Observações</h3>
      <textarea id="obs" class="mdp-textarea" maxlength="300" placeholder="Sem cebola, ponto de referência..."></textarea>
      <div class="mdp-card" style="background:#f9fafb;margin-top:12px;padding:12px">
        <div style="display:flex;justify-content:space-between"><span>Subtotal</span><b>${BRL(cartTotal())}</b></div>
        <div style="display:flex;justify-content:space-between"><span>Entrega</span><b>${BRL(TAXA_ENTREGA)}</b></div>
        <div style="display:flex;justify-content:space-between;font-size:18px;margin-top:4px"><span>Total</span><b style="color:var(--primary-dark)">${BRL(cartTotal()+TAXA_ENTREGA)}</b></div>
      </div>
      <button class="mdp-btn full lg" style="margin-top:14px" id="confirm-pedido">Confirmar pedido 🍕</button>
    `);

    function renderAddrs() {
      document.getElementById('addr-list').innerHTML = enderecos.map(e =>
        '<div class="addr-card' + (e.id === selectedId ? ' selected' : '') + '" data-id="' + ESC(e.id) + '">' +
          '<b>' + ESC(e.apelido || 'Endereço') + '</b><br>' +
          '<small>' + ESC(e.rua) + ', ' + ESC(e.numero) + (e.complemento ? ' — ' + ESC(e.complemento) : '') + '</small><br>' +
          '<small>' + ESC(e.bairro) + ', ' + ESC(e.cidade) + '/' + ESC(e.estado) + '</small>' +
        '</div>'
      ).join('') +
      '<button class="mdp-btn outline" style="width:100%;margin-top:6px" onclick="adicionarNovoEndereco()">+ Novo endereço</button>';
      document.querySelectorAll('.addr-card').forEach(c => {
        c.addEventListener('click', () => { selectedId = c.dataset.id; renderAddrs(); });
      });
    }
    renderAddrs();

    document.getElementById('forma_pgto').addEventListener('change', e => {
      document.getElementById('troco-field').style.display = e.target.value === 'dinheiro' ? 'block' : 'none';
    });

    document.getElementById('confirm-pedido').addEventListener('click', async () => {
      if (!MDPSecurity.rateLimit('pedido', 5)) return MDPUI.toast('Aguarde…', 'warn');
      const btn = document.getElementById('confirm-pedido');
      btn.disabled = true; btn.textContent = 'Enviando…';
      try {
        const addr = enderecos.find(e => e.id === selectedId);
        const itens = cart.map(i => ({ id: i.id, nome: i.nome, qty: i.qty, preco: i.preco, subtotal: i.qty * i.preco }));
        const pedidoId = 'ped-' + MDPSecurity.randomHex(8);
        const numero = '#' + Math.floor(1000 + Math.random() * 9000);
        const created = await MDPApi.create('pedidos', {
          id: pedidoId,
          numero: numero,
          cliente_id: session.uid,
          cliente_nome: session.nome,
          cliente_telefone: '',
          endereco_json: JSON.stringify(addr),
          itens_json: JSON.stringify(itens),
          subtotal: cartTotal(),
          taxa_entrega: TAXA_ENTREGA,
          total: cartTotal() + TAXA_ENTREGA,
          forma_pagamento: document.getElementById('forma_pgto').value,
          troco_para: parseFloat(document.getElementById('troco_para') ? document.getElementById('troco_para').value || 0 : 0),
          observacoes: MDPSecurity.cleanInput(document.getElementById('obs').value, 300),
          status: 'pendente',
          motoboy_id: '',
          origem: 'app',
          criado_por: session.uid,
          created_at_ms: Date.now()
        });
        cart = []; saveCart(); renderCart(); closeModal();
        pedidoAtivo = created;
        renderBannerAtivo();
        startPolling();
        abrirRastreio();
        MDPUI.toast('Pedido enviado! 🍕', 'success');
      } catch (e) {
        console.error(e);
        MDPUI.toast('Erro ao enviar pedido', 'error');
        btn.disabled = false; btn.textContent = 'Confirmar pedido 🍕';
      }
    });
  };

  // ===== Banner pedido ativo =====
  function renderBannerAtivo() {
    if (!pedidoAtivo) return;
    const b = document.getElementById('pedido-ativo-banner');
    const labels = { pendente: 'Recebido', preparando: 'Preparando', pronto: 'Pronto', saiu_entrega: 'Saiu p/ entrega' };
    b.style.cssText = 'position:sticky;top:60px;background:#dbeafe;color:#1e40af;padding:12px 18px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;z-index:50;border-bottom:1px solid #93c5fd';
    b.innerHTML = '<div><b>Pedido ' + ESC(pedidoAtivo.numero) + '</b> · ' + ESC(labels[pedidoAtivo.status] || pedidoAtivo.status) + '</div><span>Acompanhar →</span>';
    b.style.display = 'flex';
    b.onclick = abrirRastreio;
  }

  // ===== Modal: Rastreio =====
  window.abrirRastreio = function () {
    if (!pedidoAtivo) return;
    showModal(`
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
        <h2>Pedido ${ESC(pedidoAtivo.numero)}</h2>
        <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">✕</button>
      </div>
      <div class="status-row" id="status-row"></div>
      <div id="inatividade-msg" style="display:none;background:#fef3c7;color:#78350f;padding:10px 14px;border-radius:10px;font-size:13px;margin-bottom:8px"></div>
      <div id="rastreio-info"></div>
      <div id="map-rastreio"></div>
    `);
    updateStatusModalIfOpen();
    if (pedidoAtivo.status === 'saiu_entrega' && pedidoAtivo.motoboy_id) refreshMotoboyPos();
  };

  function updateStatusModalIfOpen() {
    const row = document.getElementById('status-row');
    if (!row || !pedidoAtivo) return;
    const steps = ['pendente','preparando','pronto','saiu_entrega','entregue'];
    const labels = { pendente:'Recebido', preparando:'Preparando', pronto:'Pronto', saiu_entrega:'Saiu', entregue:'Entregue' };
    const idx = steps.indexOf(pedidoAtivo.status);
    row.innerHTML = steps.map((s, i) => {
      const cls = i < idx ? 'done' : i === idx ? 'active' : '';
      return '<div class="status-step ' + cls + '">' + labels[s] + '</div>';
    }).join('');
    const info = document.getElementById('rastreio-info');
    if (info) {
      let msg = '';
      if (pedidoAtivo.status === 'pendente') msg = 'Aguardando a loja confirmar…';
      else if (pedidoAtivo.status === 'preparando') msg = '🍕 Sua pizza está sendo preparada com carinho!';
      else if (pedidoAtivo.status === 'pronto') msg = 'Pronto! Saindo para entrega…';
      else if (pedidoAtivo.status === 'saiu_entrega') msg = '🛵 A motinho está a caminho!';
      info.innerHTML = '<p style="text-align:center;color:var(--text-muted);margin:10px 0">' + msg + '</p>';
    }
  }

  // ===== Endereços novos rápidos =====
  window.adicionarNovoEndereco = async function () {
    const cep = await MDPUI.promptDialog('CEP do novo endereço:');
    if (!cep) return;
    let dados = { rua:'', bairro:'', cidade:'Queimados', estado:'RJ' };
    try { dados = await MDPValidators.lookupCEP(cep); } catch (_) {}
    const num = await MDPUI.promptDialog('Número:');
    if (!num) return;
    const apelido = await MDPUI.promptDialog('Apelido (Casa, Trabalho...):', 'Outro');
    const novo = await MDPApi.create('enderecos', {
      id: 'end-' + MDPSecurity.randomHex(8),
      user_id: session.uid,
      apelido: apelido || 'Outro',
      cep: cep.replace(/\D/g, ''),
      rua: dados.rua, numero: num,
      complemento: '', bairro: dados.bairro,
      cidade: dados.cidade, estado: dados.estado,
      principal: false, referencia: ''
    });
    enderecos.push(novo);
    abrirCheckout();
  };

  // ===== Perfil =====
  window.abrirPerfil = function () {
    showModal(`
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <h2>Meu perfil</h2>
        <button onclick="closeModal()" style="background:none;border:none;font-size:24px;cursor:pointer">✕</button>
      </div>
      <div class="mdp-card" style="background:#f9fafb">
        <b>${ESC(session.nome)}</b><br>
        <small>${ESC(session.email)}</small>
      </div>
      <h3 style="margin-top:14px">Meus endereços</h3>
      <div id="perfil-addrs"></div>
      <button class="mdp-btn outline" style="width:100%;margin-top:8px" onclick="adicionarNovoEndereco()">+ Adicionar endereço</button>
      <button class="mdp-btn danger full" style="margin-top:18px" onclick="logout()">Sair da conta</button>
    `);
    document.getElementById('perfil-addrs').innerHTML = enderecos.map(e =>
      '<div class="addr-card"><b>' + ESC(e.apelido) + '</b><br><small>' + ESC(e.rua) + ', ' + ESC(e.numero) + ' — ' + ESC(e.bairro) + '</small></div>'
    ).join('') || '<p style="color:var(--text-muted)">Nenhum endereço cadastrado.</p>';
  };

  window.logout = function () {
    MDPSecurity.clearSession();
    location.href = 'index.html';
  };

  // ===== Modal infra =====
  window.showModal = function (html) {
    closeModal();
    const bg = document.createElement('div');
    bg.className = 'modal-bg';
    bg.id = 'modal-bg';
    bg.addEventListener('click', e => { if (e.target === bg) closeModal(); });
    const m = document.createElement('div');
    m.className = 'modal';
    m.innerHTML = html;
    bg.appendChild(m);
    document.body.appendChild(bg);
  };
  window.closeModal = function () {
    const m = document.getElementById('modal-bg');
    if (m) m.remove();
  };
})();
