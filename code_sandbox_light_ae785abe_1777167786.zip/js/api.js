/* ============================================================
 * api.js — Wrapper sobre o RESTful Table API
 * ============================================================ */
(function (global) {
  'use strict';

  async function jsonFetch(url, opts) {
    opts = opts || {};
    opts.headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
    const r = await fetch(url, opts);
    if (r.status === 204) return null;
    const ct = r.headers.get('content-type') || '';
    let body = null;
    if (ct.indexOf('application/json') >= 0) {
      body = await r.json();
    } else {
      body = await r.text();
    }
    if (!r.ok) {
      const err = new Error(body && body.message ? body.message : 'HTTP ' + r.status);
      err.status = r.status;
      err.body = body;
      throw err;
    }
    return body;
  }

  async function listAll(table, opts) {
    opts = opts || {};
    const limit = opts.limit || 1000;
    const search = opts.search ? '&search=' + encodeURIComponent(opts.search) : '';
    const sort = opts.sort ? '&sort=' + encodeURIComponent(opts.sort) : '';
    const r = await jsonFetch('tables/' + table + '?page=1&limit=' + limit + search + sort);
    return r && r.data ? r.data : [];
  }

  async function getOne(table, id) {
    return await jsonFetch('tables/' + table + '/' + encodeURIComponent(id));
  }

  async function create(table, data) {
    return await jsonFetch('tables/' + table, { method: 'POST', body: JSON.stringify(data) });
  }

  async function update(table, id, data) {
    return await jsonFetch('tables/' + table + '/' + encodeURIComponent(id), {
      method: 'PUT', body: JSON.stringify(data)
    });
  }

  async function patch(table, id, data) {
    return await jsonFetch('tables/' + table + '/' + encodeURIComponent(id), {
      method: 'PATCH', body: JSON.stringify(data)
    });
  }

  async function remove(table, id) {
    return await jsonFetch('tables/' + table + '/' + encodeURIComponent(id), { method: 'DELETE' });
  }

  // Helpers
  async function findUserByEmail(email) {
    email = String(email || '').trim().toLowerCase();
    const all = await listAll('users', { limit: 1000 });
    return all.find(function (u) { return u.email && u.email.toLowerCase() === email && !u.deleted; }) || null;
  }

  async function getQRSecret() {
    try {
      const s = await getOne('qr_secret', 'singleton');
      return s && s.secret ? s.secret : null;
    } catch (_) {
      return null;
    }
  }

  global.MDPApi = {
    list: listAll, get: getOne, create, update, patch, delete: remove,
    findUserByEmail, getQRSecret
  };
})(window);
