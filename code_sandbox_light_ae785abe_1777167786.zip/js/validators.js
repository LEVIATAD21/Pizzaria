/* ============================================================
 * validators.js — Validações reais brasileiras
 * ============================================================ */
(function (global) {
  'use strict';

  // CPF — algoritmo oficial com dígitos verificadores
  function isValidCPF(cpf) {
    if (!cpf) return false;
    cpf = String(cpf).replace(/\D/g, '');
    if (cpf.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cpf)) return false; // todos iguais
    let s = 0;
    for (let i = 0; i < 9; i++) s += parseInt(cpf.charAt(i)) * (10 - i);
    let d = 11 - (s % 11); if (d >= 10) d = 0;
    if (d !== parseInt(cpf.charAt(9))) return false;
    s = 0;
    for (let i = 0; i < 10; i++) s += parseInt(cpf.charAt(i)) * (11 - i);
    d = 11 - (s % 11); if (d >= 10) d = 0;
    return d === parseInt(cpf.charAt(10));
  }

  function maskCPF(cpf) {
    cpf = String(cpf || '').replace(/\D/g, '').substring(0, 11);
    return cpf
      .replace(/^(\d{3})(\d)/, '$1.$2')
      .replace(/^(\d{3})\.(\d{3})(\d)/, '$1.$2.$3')
      .replace(/\.(\d{3})(\d)/, '.$1-$2');
  }

  function maskCPFHidden(cpf) {
    cpf = String(cpf || '').replace(/\D/g, '');
    if (cpf.length !== 11) return cpf;
    return '***.' + cpf.substring(3, 6) + '.' + cpf.substring(6, 9) + '-**';
  }

  // CNH — 11 dígitos, validação simples de dígito
  function isValidCNH(cnh) {
    if (!cnh) return false;
    cnh = String(cnh).replace(/\D/g, '');
    if (cnh.length !== 11) return false;
    if (/^(\d)\1{10}$/.test(cnh)) return false;
    let dsc = 0, v = 0;
    for (let i = 0, j = 9; i < 9; i++, j--) v += parseInt(cnh.charAt(i)) * j;
    let d1 = v % 11;
    if (d1 >= 10) { d1 = 0; dsc = -2; }
    v = 0;
    for (let i = 0, j = 1; i < 9; i++, j++) v += parseInt(cnh.charAt(i)) * j;
    let x = v % 11;
    let d2 = (x >= 10) ? 0 : x + dsc;
    return parseInt(cnh.charAt(9)) === (d1 < 0 ? 0 : d1) &&
           parseInt(cnh.charAt(10)) === (d2 < 0 ? 0 : d2);
  }

  // Placa Mercosul (AAA0A00) ou antiga (AAA0000)
  function isValidPlaca(placa) {
    if (!placa) return false;
    placa = String(placa).toUpperCase().replace(/[^A-Z0-9]/g, '');
    return /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(placa);
  }

  function maskPlaca(placa) {
    placa = String(placa || '').toUpperCase().replace(/[^A-Z0-9]/g, '').substring(0, 7);
    if (placa.length > 3) placa = placa.substring(0, 3) + '-' + placa.substring(3);
    return placa;
  }

  // Telefone BR (10 ou 11 dígitos)
  function isValidTelefone(tel) {
    if (!tel) return false;
    tel = String(tel).replace(/\D/g, '');
    return tel.length === 10 || tel.length === 11;
  }

  function maskTelefone(tel) {
    tel = String(tel || '').replace(/\D/g, '').substring(0, 11);
    if (tel.length <= 2) return tel ? '(' + tel : '';
    if (tel.length <= 7) return '(' + tel.substring(0, 2) + ') ' + tel.substring(2);
    if (tel.length <= 10) return '(' + tel.substring(0, 2) + ') ' + tel.substring(2, 6) + '-' + tel.substring(6);
    return '(' + tel.substring(0, 2) + ') ' + tel.substring(2, 7) + '-' + tel.substring(7);
  }

  // CEP
  function isValidCEP(cep) {
    cep = String(cep || '').replace(/\D/g, '');
    return cep.length === 8;
  }

  function maskCEP(cep) {
    cep = String(cep || '').replace(/\D/g, '').substring(0, 8);
    if (cep.length > 5) return cep.substring(0, 5) + '-' + cep.substring(5);
    return cep;
  }

  // Email simples
  function isValidEmail(email) {
    if (!email) return false;
    email = String(email).trim().toLowerCase();
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 120;
  }

  // Senha forte: 8+ chars, 1 letra, 1 número
  function isStrongPassword(pw) {
    if (!pw || pw.length < 8) return false;
    return /[A-Za-z]/.test(pw) && /\d/.test(pw);
  }

  // ViaCEP lookup (público, CORS aberto)
  async function lookupCEP(cep) {
    cep = String(cep || '').replace(/\D/g, '');
    if (cep.length !== 8) throw new Error('CEP inválido');
    const r = await fetch('https://viacep.com.br/ws/' + cep + '/json/');
    if (!r.ok) throw new Error('Erro ao consultar CEP');
    const data = await r.json();
    if (data.erro) throw new Error('CEP não encontrado');
    return {
      cep: data.cep,
      rua: data.logradouro || '',
      bairro: data.bairro || '',
      cidade: data.localidade || '',
      estado: data.uf || ''
    };
  }

  global.MDPValidators = {
    isValidCPF, maskCPF, maskCPFHidden,
    isValidCNH,
    isValidPlaca, maskPlaca,
    isValidTelefone, maskTelefone,
    isValidCEP, maskCEP, lookupCEP,
    isValidEmail, isStrongPassword
  };
})(window);
